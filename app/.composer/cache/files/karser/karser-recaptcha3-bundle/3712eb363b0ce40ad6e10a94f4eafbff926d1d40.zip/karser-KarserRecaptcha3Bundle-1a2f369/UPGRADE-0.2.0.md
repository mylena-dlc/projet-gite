### UPGRADE FROM 0.1.* to 0.2.0

Everything after \ReCaptcha\* namespace was moved into \Karser\Recaptcha3Bundle\ReCaptcha

Before:
```
use ReCaptcha\ReCaptcha;
```
After:
```
use Karser\Recaptcha3Bundle\ReCaptcha\ReCaptcha;
```
