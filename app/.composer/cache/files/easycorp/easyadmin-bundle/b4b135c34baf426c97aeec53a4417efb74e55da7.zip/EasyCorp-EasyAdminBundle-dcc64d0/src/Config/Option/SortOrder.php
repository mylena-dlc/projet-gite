<?php

namespace EasyCorp\Bundle\EasyAdminBundle\Config\Option;

/**
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
final class SortOrder
{
    public const ASC = 'ASC';
    public const DESC = 'DESC';
}
