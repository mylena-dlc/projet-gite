EasyAdmin 2.x Default Theme
(c) 2018 Javier Eguiluz

You can freely use this design when building web sites and applications using
EasyAdmin, no matter if they are free, commercial or open source.

You cannot use this design or any of its distinctive elements in your own
web site, application or service built without EasyAdmin, no matter if they
are free, commercial or open source.
