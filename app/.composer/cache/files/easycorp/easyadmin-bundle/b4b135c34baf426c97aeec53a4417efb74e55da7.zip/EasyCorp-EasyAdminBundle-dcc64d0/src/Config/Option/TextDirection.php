<?php

namespace EasyCorp\Bundle\EasyAdminBundle\Config\Option;

/**
 * @author Javier Eguiluz <javier.eguiluz@gmail.com>
 */
final class TextDirection
{
    public const LTR = 'ltr';
    public const RTL = 'rtl';
}
