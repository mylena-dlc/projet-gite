<?php

namespace CoreInterfaces\Sdk;

interface ExceptionInterface extends \Throwable
{
}
