<?php

declare(strict_types=1);

namespace Core\Tests\Mocking\Types;

use Core\Types\Sdk\CoreCallback;

class MockCallback extends CoreCallback
{
}
