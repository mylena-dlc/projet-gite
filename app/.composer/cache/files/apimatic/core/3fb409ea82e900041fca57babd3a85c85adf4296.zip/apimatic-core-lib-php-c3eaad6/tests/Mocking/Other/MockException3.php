<?php

namespace Core\Tests\Mocking\Other;

class MockException3 extends MockException
{
    /**
     * @var MockClass
     */
    public $other3;
}
