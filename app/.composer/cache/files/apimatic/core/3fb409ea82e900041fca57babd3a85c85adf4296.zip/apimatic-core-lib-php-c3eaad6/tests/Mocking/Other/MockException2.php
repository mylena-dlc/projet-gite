<?php

namespace Core\Tests\Mocking\Other;

class MockException2 extends MockException
{
    /**
     * @var MockClass
     */
    public $other2;
}
