<?php

declare(strict_types=1);

namespace Core\Tests\Mocking\Types;

use Core\Types\Sdk\CoreRequest;

class MockRequest extends CoreRequest
{
}
