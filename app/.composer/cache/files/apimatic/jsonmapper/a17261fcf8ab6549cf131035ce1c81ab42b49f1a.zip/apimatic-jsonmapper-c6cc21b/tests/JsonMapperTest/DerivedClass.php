<?php

/**
 * @discriminator type
 * @discriminatorType derived1
 */
class JsonMapperTest_DerivedClass extends JsonMapperTest_SimpleBase
{
	public $derived1Field;
}
