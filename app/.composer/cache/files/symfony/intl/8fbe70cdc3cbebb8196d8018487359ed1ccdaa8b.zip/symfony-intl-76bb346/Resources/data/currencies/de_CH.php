<?php

return [
    'Names' => [
        'BYN' => [
            'BYN',
            'Weissrussischer Rubel',
        ],
        'BYR' => [
            'BYR',
            'Weissrussischer Rubel (2000–2016)',
        ],
        'EUR' => [
            'EUR',
            'Euro',
        ],
        'STN' => [
            'STN',
            'São-toméischer Dobra (2018)',
        ],
    ],
];
