<?php

return [
    'Names' => [
        'AFN' => [
            '؋',
            'افغانی',
        ],
    ],
];
