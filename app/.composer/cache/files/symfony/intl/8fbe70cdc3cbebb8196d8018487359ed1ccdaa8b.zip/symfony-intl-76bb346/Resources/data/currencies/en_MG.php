<?php

return [
    'Names' => [
        'MGA' => [
            'Ar',
            'Malagasy Ariary',
        ],
    ],
];
