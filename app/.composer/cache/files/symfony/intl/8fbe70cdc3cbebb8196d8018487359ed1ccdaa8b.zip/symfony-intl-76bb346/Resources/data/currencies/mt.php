<?php

return [
    'Names' => [
        'EUR' => [
            '€',
            'ewro',
        ],
        'MTL' => [
            'MTL',
            'Lira Maltija',
        ],
        'PHP' => [
            'PHP',
            'PHP',
        ],
    ],
];
