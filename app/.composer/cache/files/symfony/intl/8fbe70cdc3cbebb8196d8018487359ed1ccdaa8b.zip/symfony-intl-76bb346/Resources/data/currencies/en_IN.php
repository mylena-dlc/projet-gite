<?php

return [
    'Names' => [
        'KGS' => [
            'KGS',
            'Kyrgyzstani Som',
        ],
        'USD' => [
            '$',
            'US Dollar',
        ],
        'VEF' => [
            'VEF',
            'Venezuelan Bolívar',
        ],
        'VES' => [
            'VES',
            'VEF',
        ],
    ],
];
