<?php

return [
    'Names' => [
        'ERN' => [
            'Nfk',
            'ناكفا أريتري',
        ],
    ],
];
