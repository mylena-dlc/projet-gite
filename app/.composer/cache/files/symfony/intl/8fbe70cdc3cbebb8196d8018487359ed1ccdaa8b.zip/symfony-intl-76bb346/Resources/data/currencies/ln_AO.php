<?php

return [
    'Names' => [
        'AOA' => [
            'Kz',
            'Kwanza ya Angóla',
        ],
    ],
];
