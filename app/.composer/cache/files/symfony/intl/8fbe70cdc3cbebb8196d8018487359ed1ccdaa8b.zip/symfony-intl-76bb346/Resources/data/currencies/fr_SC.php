<?php

return [
    'Names' => [
        'SCR' => [
            'SR',
            'roupie des Seychelles',
        ],
    ],
];
