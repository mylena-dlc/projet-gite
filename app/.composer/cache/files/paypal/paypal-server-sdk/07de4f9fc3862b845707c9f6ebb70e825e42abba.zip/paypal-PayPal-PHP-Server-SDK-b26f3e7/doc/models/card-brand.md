
# Card Brand

The card network or brand. Applies to credit, debit, gift, and payment cards.

## Enumeration

`CardBrand`

## Fields

| Name |
|  --- |
| `VISA` |
| `MASTERCARD` |
| `DISCOVER` |
| `AMEX` |
| `SOLO` |
| `JCB` |
| `STAR` |
| `DELTA` |
| `SWITCH_` |
| `MAESTRO` |
| `CB_NATIONALE` |
| `CONFIGOGA` |
| `CONFIDIS` |
| `ELECTRON` |
| `CETELEM` |
| `CHINA_UNION_PAY` |
| `DINERS` |
| `ELO` |
| `HIPER` |
| `HIPERCARD` |
| `RUPAY` |
| `GE` |
| `SYNCHRONY` |
| `EFTPOS` |
| `UNKNOWN` |

