
# Google Pay Payment Method

The type of the payment credential. Currently, only CARD is supported.

## Enumeration

`GooglePayPaymentMethod`

## Fields

| Name |
|  --- |
| `CARD` |

