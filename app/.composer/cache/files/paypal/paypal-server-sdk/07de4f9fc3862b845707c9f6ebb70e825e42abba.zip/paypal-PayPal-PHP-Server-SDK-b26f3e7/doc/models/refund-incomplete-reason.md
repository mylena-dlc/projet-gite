
# Refund Incomplete Reason

The reason why the refund has the `PENDING` or `FAILED` status.

## Enumeration

`RefundIncompleteReason`

## Fields

| Name |
|  --- |
| `ECHECK` |

