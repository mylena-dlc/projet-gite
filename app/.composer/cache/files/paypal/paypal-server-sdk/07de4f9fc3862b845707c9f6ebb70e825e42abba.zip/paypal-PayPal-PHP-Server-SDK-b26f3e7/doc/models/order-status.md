
# Order Status

The order status.

## Enumeration

`OrderStatus`

## Fields

| Name |
|  --- |
| `CREATED` |
| `SAVED` |
| `APPROVED` |
| `VOIDED` |
| `COMPLETED` |
| `PAYER_ACTION_REQUIRED` |

