
# Capture Status

The status of the captured payment.

## Enumeration

`CaptureStatus`

## Fields

| Name |
|  --- |
| `COMPLETED` |
| `DECLINED` |
| `PARTIALLY_REFUNDED` |
| `PENDING` |
| `REFUNDED` |
| `FAILED` |

