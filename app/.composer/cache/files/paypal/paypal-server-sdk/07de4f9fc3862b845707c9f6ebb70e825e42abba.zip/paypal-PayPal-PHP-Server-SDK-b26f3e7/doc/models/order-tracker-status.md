
# Order Tracker Status

The status of the item shipment.

## Enumeration

`OrderTrackerStatus`

## Fields

| Name |
|  --- |
| `CANCELLED` |
| `SHIPPED` |

