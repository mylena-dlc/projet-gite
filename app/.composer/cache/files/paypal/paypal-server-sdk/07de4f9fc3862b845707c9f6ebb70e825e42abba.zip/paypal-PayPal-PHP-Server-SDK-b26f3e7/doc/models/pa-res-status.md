
# Pa Res Status

Transactions status result identifier. The outcome of the issuer's authentication.

## Enumeration

`PaResStatus`

## Fields

| Name |
|  --- |
| `Y` |
| `N` |
| `U` |
| `A` |
| `C` |
| `R` |
| `D` |
| `I` |

