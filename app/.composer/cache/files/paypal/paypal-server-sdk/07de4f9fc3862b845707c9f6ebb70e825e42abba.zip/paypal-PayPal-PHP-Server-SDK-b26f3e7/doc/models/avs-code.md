
# Avs Code

The address verification code for Visa, Discover, Mastercard, or American Express transactions.

## Enumeration

`AvsCode`

## Fields

| Name |
|  --- |
| `A` |
| `B` |
| `C` |
| `D` |
| `E` |
| `F` |
| `G` |
| `I` |
| `M` |
| `N` |
| `P` |
| `R` |
| `S` |
| `U` |
| `W` |
| `X` |
| `Y` |
| `Z` |
| `NULL` |
| `ENUM_0` |
| `ENUM_1` |
| `ENUM_2` |
| `ENUM_3` |
| `ENUM_4` |

