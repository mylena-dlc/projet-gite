
# Dispute Category

The condition that is covered for the transaction.

## Enumeration

`DisputeCategory`

## Fields

| Name |
|  --- |
| `ITEM_NOT_RECEIVED` |
| `UNAUTHORIZED_TRANSACTION` |

