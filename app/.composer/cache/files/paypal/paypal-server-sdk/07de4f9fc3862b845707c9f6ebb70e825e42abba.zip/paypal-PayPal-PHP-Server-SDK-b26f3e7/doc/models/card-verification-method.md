
# Card Verification Method

The method used for card verification.

## Enumeration

`CardVerificationMethod`

## Fields

| Name |
|  --- |
| `SCA_ALWAYS` |
| `SCA_WHEN_REQUIRED` |
| `ENUM_3D_SECURE` |
| `AVS_CVV` |

