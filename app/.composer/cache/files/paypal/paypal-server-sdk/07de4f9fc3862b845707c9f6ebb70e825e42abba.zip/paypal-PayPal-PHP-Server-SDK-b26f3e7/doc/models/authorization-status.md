
# Authorization Status

The status for the authorized payment.

## Enumeration

`AuthorizationStatus`

## Fields

| Name |
|  --- |
| `CREATED` |
| `CAPTURED` |
| `DENIED` |
| `PARTIALLY_CAPTURED` |
| `VOIDED` |
| `PENDING` |

