
# Payee Payment Method Preference

The merchant-preferred payment methods.

## Enumeration

`PayeePaymentMethodPreference`

## Fields

| Name |
|  --- |
| `UNRESTRICTED` |
| `IMMEDIATE_PAYMENT_REQUIRED` |

