
# Paypal Experience User Action

Configures a <strong>Continue</strong> or <strong>Pay Now</strong> checkout flow.

## Enumeration

`PaypalExperienceUserAction`

## Fields

| Name |
|  --- |
| `CONTINUE_` |
| `PAY_NOW` |

