
# Stored Payment Source Payment Type

Indicates the type of the stored payment_source payment.

## Enumeration

`StoredPaymentSourcePaymentType`

## Fields

| Name |
|  --- |
| `ONE_TIME` |
| `RECURRING` |
| `UNSCHEDULED` |

