
# Shipping Type

A classification for the method of purchase fulfillment.

## Enumeration

`ShippingType`

## Fields

| Name |
|  --- |
| `SHIPPING` |
| `PICKUP` |
| `PICKUP_IN_STORE` |
| `PICKUP_FROM_PERSON` |

