
# Cvv Code

The card verification value code for for Visa, Discover, Mastercard, or American Express.

## Enumeration

`CvvCode`

## Fields

| Name |
|  --- |
| `E` |
| `I` |
| `M` |
| `N` |
| `P` |
| `S` |
| `U` |
| `X` |
| `ENUM_ALL_OTHERS` |
| `ENUM_0` |
| `ENUM_1` |
| `ENUM_2` |
| `ENUM_3` |
| `ENUM_4` |

