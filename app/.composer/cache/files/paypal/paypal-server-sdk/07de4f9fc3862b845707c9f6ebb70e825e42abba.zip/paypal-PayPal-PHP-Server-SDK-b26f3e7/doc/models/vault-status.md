
# Vault Status

The vault status.

## Enumeration

`VaultStatus`

## Fields

| Name |
|  --- |
| `VAULTED` |
| `CREATED` |
| `APPROVED` |

