
# Item Category

The item category type.

## Enumeration

`ItemCategory`

## Fields

| Name |
|  --- |
| `DIGITAL_GOODS` |
| `PHYSICAL_GOODS` |
| `DONATION` |

