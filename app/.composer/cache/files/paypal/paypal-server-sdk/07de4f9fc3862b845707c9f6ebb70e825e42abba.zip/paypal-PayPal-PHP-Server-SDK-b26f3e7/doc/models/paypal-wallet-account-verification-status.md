
# Paypal Wallet Account Verification Status

The account status indicates whether the buyer has verified the financial details associated with their PayPal account.

## Enumeration

`PaypalWalletAccountVerificationStatus`

## Fields

| Name |
|  --- |
| `VERIFIED` |
| `UNVERIFIED` |

