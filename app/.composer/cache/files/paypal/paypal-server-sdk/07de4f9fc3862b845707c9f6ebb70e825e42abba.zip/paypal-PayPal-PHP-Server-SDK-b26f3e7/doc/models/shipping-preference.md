
# Shipping Preference

The location from which the shipping address is derived.

## Enumeration

`ShippingPreference`

## Fields

| Name |
|  --- |
| `GET_FROM_FILE` |
| `NO_SHIPPING` |
| `SET_PROVIDED_ADDRESS` |

