
# Upc Type

The Universal Product Code type.

## Enumeration

`UpcType`

## Fields

| Name |
|  --- |
| `UPCA` |
| `UPCB` |
| `UPCC` |
| `UPCD` |
| `UPCE` |
| `UPC2` |
| `UPC5` |

