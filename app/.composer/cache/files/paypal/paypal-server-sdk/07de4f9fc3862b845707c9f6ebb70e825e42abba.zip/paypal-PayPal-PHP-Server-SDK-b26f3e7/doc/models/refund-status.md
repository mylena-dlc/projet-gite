
# Refund Status

The status of the refund.

## Enumeration

`RefundStatus`

## Fields

| Name |
|  --- |
| `CANCELLED` |
| `FAILED` |
| `PENDING` |
| `COMPLETED` |

