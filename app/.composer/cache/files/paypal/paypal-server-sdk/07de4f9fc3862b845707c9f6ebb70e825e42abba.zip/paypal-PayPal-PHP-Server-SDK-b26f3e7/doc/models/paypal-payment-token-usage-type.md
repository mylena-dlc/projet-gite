
# Paypal Payment Token Usage Type

The usage type associated with the PayPal payment token.

## Enumeration

`PaypalPaymentTokenUsageType`

## Fields

| Name |
|  --- |
| `MERCHANT` |
| `PLATFORM` |

