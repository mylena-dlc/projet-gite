
# Paypal Experience Landing Page

The type of landing page to show on the PayPal site for customer checkout.

## Enumeration

`PaypalExperienceLandingPage`

## Fields

| Name |
|  --- |
| `LOGIN` |
| `GUEST_CHECKOUT` |
| `NO_PREFERENCE` |

