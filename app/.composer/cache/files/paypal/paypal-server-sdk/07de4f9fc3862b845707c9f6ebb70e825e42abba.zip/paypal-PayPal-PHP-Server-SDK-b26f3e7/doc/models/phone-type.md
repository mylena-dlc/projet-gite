
# Phone Type

The phone type.

## Enumeration

`PhoneType`

## Fields

| Name |
|  --- |
| `FAX` |
| `HOME` |
| `MOBILE` |
| `OTHER` |
| `PAGER` |

