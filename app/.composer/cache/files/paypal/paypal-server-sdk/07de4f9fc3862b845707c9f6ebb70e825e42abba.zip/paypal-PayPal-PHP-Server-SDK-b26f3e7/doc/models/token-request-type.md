
# Token Request Type

The tokenization method that generated the ID.

## Enumeration

`TokenRequestType`

## Fields

| Name |
|  --- |
| `SETUP_TOKEN` |
| `BILLING_AGREEMENT` |

