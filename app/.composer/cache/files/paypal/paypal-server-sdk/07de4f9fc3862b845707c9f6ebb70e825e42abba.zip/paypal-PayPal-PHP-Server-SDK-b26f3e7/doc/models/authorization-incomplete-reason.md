
# Authorization Incomplete Reason

The reason why the authorized status is `PENDING`.

## Enumeration

`AuthorizationIncompleteReason`

## Fields

| Name |
|  --- |
| `PENDING_REVIEW` |
| `DECLINED_BY_RISK_FRAUD_FILTERS` |

