
# Enrollment Status

Status of Authentication eligibility.

## Enumeration

`EnrollmentStatus`

## Fields

| Name |
|  --- |
| `Y` |
| `N` |
| `U` |
| `B` |

