
# Liability Shift Indicator

Liability shift indicator. The outcome of the issuer's authentication.

## Enumeration

`LiabilityShiftIndicator`

## Fields

| Name |
|  --- |
| `NO` |
| `POSSIBLE` |
| `UNKNOWN` |

