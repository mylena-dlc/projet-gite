
# Payment Initiator

The person or party who initiated or triggered the payment.

## Enumeration

`PaymentInitiator`

## Fields

| Name |
|  --- |
| `CUSTOMER` |
| `MERCHANT` |

