
# Payment Advice Code

The declined payment transactions might have payment advice codes. The card networks, like Visa and Mastercard, return payment advice codes.

## Enumeration

`PaymentAdviceCode`

## Fields

| Name |
|  --- |
| `ENUM_01` |
| `ENUM_02` |
| `ENUM_03` |
| `ENUM_21` |

