
# Paypal Wallet Vault Status

The vault status.

## Enumeration

`PaypalWalletVaultStatus`

## Fields

| Name |
|  --- |
| `VAULTED` |
| `CREATED` |
| `APPROVED` |

