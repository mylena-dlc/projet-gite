
# Store in Vault Instruction

Defines how and when the payment source gets vaulted.

## Enumeration

`StoreInVaultInstruction`

## Fields

| Name |
|  --- |
| `ON_SUCCESS` |

