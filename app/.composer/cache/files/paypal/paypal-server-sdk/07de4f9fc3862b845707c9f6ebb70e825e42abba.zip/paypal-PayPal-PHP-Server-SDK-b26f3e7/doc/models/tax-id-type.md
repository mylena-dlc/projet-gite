
# Tax Id Type

The customer's tax ID type.

## Enumeration

`TaxIdType`

## Fields

| Name |
|  --- |
| `BR_CPF` |
| `BR_CNPJ` |

