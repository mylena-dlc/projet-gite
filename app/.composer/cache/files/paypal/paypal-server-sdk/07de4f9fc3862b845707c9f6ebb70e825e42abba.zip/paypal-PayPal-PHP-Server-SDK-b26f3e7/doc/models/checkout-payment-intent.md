
# Checkout Payment Intent

The intent to either capture payment immediately or authorize a payment for an order after order creation.

## Enumeration

`CheckoutPaymentIntent`

## Fields

| Name |
|  --- |
| `CAPTURE` |
| `AUTHORIZE` |

