
# Google Pay Authentication Method

Authentication Method which is used for the card transaction.

## Enumeration

`GooglePayAuthenticationMethod`

## Fields

| Name |
|  --- |
| `PAN_ONLY` |
| `CRYPTOGRAM_3DS` |

