
# Link Http Method

The HTTP method required to make the related call.

## Enumeration

`LinkHttpMethod`

## Fields

| Name |
|  --- |
| `GET` |
| `POST` |
| `PUT` |
| `DELETE` |
| `HEAD` |
| `CONNECT` |
| `OPTIONS` |
| `PATCH` |

