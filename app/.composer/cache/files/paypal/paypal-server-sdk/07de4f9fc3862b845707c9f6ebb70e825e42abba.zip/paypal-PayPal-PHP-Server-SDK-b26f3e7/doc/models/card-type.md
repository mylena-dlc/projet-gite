
# Card Type

Type of card. i.e Credit, Debit and so on.

## Enumeration

`CardType`

## Fields

| Name |
|  --- |
| `CREDIT` |
| `DEBIT` |
| `PREPAID` |
| `STORE` |
| `UNKNOWN` |

