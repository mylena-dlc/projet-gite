
# Venmo Payment Token Usage Type

The usage type associated with the Venmo payment token.

## Enumeration

`VenmoPaymentTokenUsageType`

## Fields

| Name |
|  --- |
| `MERCHANT` |
| `PLATFORM` |

