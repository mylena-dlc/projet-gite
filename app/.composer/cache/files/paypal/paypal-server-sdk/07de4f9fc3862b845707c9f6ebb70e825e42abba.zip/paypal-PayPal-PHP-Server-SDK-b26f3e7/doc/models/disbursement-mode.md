
# Disbursement Mode

The funds that are held on behalf of the merchant.

## Enumeration

`DisbursementMode`

## Fields

| Name |
|  --- |
| `INSTANT` |
| `DELAYED` |

