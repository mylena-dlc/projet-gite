
# Token Type

The tokenization method that generated the ID.

## Enumeration

`TokenType`

## Fields

| Name |
|  --- |
| `BILLING_AGREEMENT` |

