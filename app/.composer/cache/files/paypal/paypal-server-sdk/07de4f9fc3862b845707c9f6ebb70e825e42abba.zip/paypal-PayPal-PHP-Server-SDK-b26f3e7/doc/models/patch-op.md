
# Patch Op

The operation.

## Enumeration

`PatchOp`

## Fields

| Name |
|  --- |
| `ADD` |
| `REMOVE` |
| `REPLACE` |
| `MOVE` |
| `COPY` |
| `TEST` |

