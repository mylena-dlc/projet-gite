<?php
namespace Rs\Json\Pointer;

class NonWalkableJsonException extends \Exception
{
}
