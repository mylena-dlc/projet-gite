<?php
namespace Rs\Json\Pointer;

class NonexistentValueReferencedException extends \Exception
{
}
