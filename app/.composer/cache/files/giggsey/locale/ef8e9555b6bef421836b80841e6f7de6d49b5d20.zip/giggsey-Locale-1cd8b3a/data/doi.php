<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BR' => 'ब्राजील',
    'CN' => 'चीन',
    'DE' => 'जर्मनी',
    'FR' => 'फ्रांस',
    'GB' => 'यूनाइटेड किंगडम',
    'IN' => 'भारत',
    'IT' => 'इटली',
    'JP' => 'जापान',
    'RU' => 'रूस',
    'US' => 'यूएस',
];
