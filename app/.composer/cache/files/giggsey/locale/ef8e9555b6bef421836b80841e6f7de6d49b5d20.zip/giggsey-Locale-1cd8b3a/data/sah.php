<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BR' => 'Бразилия',
    'CA' => 'Канаада',
    'CL' => 'Чиили',
    'CN' => 'Кытай',
    'CU' => 'Кууба',
    'EE' => 'Эстония',
    'FI' => 'Финляндия',
    'GB' => 'Улуу Британия',
    'IE' => 'Ирландия',
    'IM' => 'Мэн арыы',
    'IS' => 'Исландия',
    'JM' => 'Дьамаайка',
    'LT' => 'Литва',
    'LV' => 'Латвия',
    'LY' => 'Лиибийэ',
    'MX' => 'Миэксикэ',
    'NO' => 'Норвегия',
    'RU' => 'Арассыыйа',
    'SD' => 'Судаан',
    'SE' => 'Швеция',
    'US' => 'Америка Холбоһуктаах Штааттара',
];
