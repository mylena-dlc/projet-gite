<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AC' => 'ostrvo Asension',
    'AX' => 'Olandska ostrva',
    'BL' => 'Sen Bartelemi',
    'BN' => 'Bruneji',
    'BY' => 'Bjelorusija',
    'CC' => 'Kokosova (Kiling) ostrva',
    'CZ' => 'Češka Republika',
    'DE' => 'Njemačka',
    'FK' => 'Foklandska ostrva',
    'FO' => 'Farska ostrva',
    'GS' => 'Južna Džordžija i Južna Sendvička ostrva',
    'GU' => 'Gvam',
    'GW' => 'Gvineja Bisao',
    'HK' => 'Hongkong (SAO Kine)',
    'KM' => 'Komori',
    'KP' => 'Sjeverna Koreja',
    'MK' => 'Sjeverna Makedonija',
    'MM' => 'Mjanmar (Burma)',
    'MP' => 'Sjeverna Marijanska ostrva',
    'NF' => 'ostrvo Norfok',
    'NU' => 'Nijue',
    'PS' => 'palestinske teritorije',
    'RE' => 'Reunion',
    'TF' => 'Francuske južne teritorije',
    'UM' => 'Spoljna ostrva SAD',
    'VC' => 'Sveti Vinsent i Grenadini',
    'VG' => 'Britanska Djevičanska ostrva',
    'VI' => 'Američka Djevičanska ostrva',
];
