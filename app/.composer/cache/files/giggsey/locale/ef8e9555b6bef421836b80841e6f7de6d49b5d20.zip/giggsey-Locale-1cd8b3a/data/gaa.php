<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'GH' => 'Ghana',
];
