<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'CN' => 'རྒྱ་ནག',
    'DE' => 'འཇར་མན་',
    'GB' => 'དབྱིན་ཇི་',
    'IN' => 'རྒྱ་གར་',
    'IT' => 'ཨི་ཀྲར་ལི་',
    'JP' => 'ཉི་ཧོང་',
    'KR' => 'ལྷོ་ཀོ་རི་ཡ།',
    'NP' => 'བལ་ཡུལ་',
    'RU' => 'ཨུ་རུ་སུ་',
    'US' => 'ཨ་མེ་རི་ཀ།',
];
