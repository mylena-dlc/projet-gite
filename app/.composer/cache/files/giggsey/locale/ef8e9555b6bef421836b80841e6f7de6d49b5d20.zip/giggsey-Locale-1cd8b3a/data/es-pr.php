<?php

declare(strict_types=1);
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AC' => 'Isla Ascensión',
    'AX' => 'Islas Åland',
    'BA' => 'Bosnia-Herzegovina',
    'CG' => 'República del Congo',
    'CI' => 'Costa de Marfil',
    'GS' => 'Islas Georgia del Sur y Sándwich del Sur',
    'IC' => 'Islas Canarias',
    'RO' => 'Rumania',
    'SA' => 'Arabia Saudita',
    'TL' => 'Timor Oriental',
];
