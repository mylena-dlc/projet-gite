<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'UM' => 'মার্কিন যুক্তরাষ্ট্রের দূরবর্তী দ্বীপপুঞ্জ',
];
