<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'CA' => 'Uŋčíyapi Makȟóčhe',
    'CN' => 'Pȟečhókaŋhaŋska Makȟóčhe',
    'DE' => 'Iyášiča Makȟóčhe',
    'ES' => 'Spayólaȟče Makȟóčhe',
    'JP' => 'Kisúŋla Makȟóčhe',
    'MX' => 'Spayóla Makȟóčhe',
    'US' => 'Mílahaŋska Tȟamákȟočhe',
];
