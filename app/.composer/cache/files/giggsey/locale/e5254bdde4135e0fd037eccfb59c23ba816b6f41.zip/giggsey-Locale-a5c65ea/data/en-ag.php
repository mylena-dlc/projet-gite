<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BL' => 'St Barthélemy',
    'KN' => 'St Kitts & Nevis',
    'LC' => 'St Lucia',
    'MF' => 'St Martin',
    'PM' => 'St Pierre & Miquelon',
    'SH' => 'St Helena',
    'UM' => 'US Outlying Islands',
    'VC' => 'St Vincent & the Grenadines',
    'VI' => 'US Virgin Islands',
];
