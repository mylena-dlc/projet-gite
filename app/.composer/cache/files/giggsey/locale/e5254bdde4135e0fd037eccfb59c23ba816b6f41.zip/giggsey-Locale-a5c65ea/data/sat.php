<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BR' => 'ᱵᱨᱟᱡᱤᱞ',
    'CN' => 'ᱪᱤᱱ',
    'DE' => 'ᱡᱟᱨᱢᱟᱱᱤ',
    'FR' => 'ᱯᱷᱨᱟᱱᱥ',
    'GB' => 'ᱭᱩᱱᱤᱭᱴᱮᱰ ᱠᱤᱝᱰᱚᱢ',
    'IN' => 'ᱤᱱᱰᱤᱭᱟ',
    'IT' => 'ᱤᱴᱞᱤ',
    'JP' => 'ᱡᱟᱯᱟᱱ',
    'RU' => 'ᱨᱩᱥ',
    'US' => 'ᱭᱩᱱᱟᱭᱴᱮᱰ ᱮᱥᱴᱮᱴ',
];
