<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'BR' => 'ब्राज़ील',
    'CN' => 'चीन',
    'DE' => 'जर्मन',
    'FR' => 'फ्रांस',
    'GB' => 'मुतहीद बादशाहत',
    'IN' => 'हिंदोस्तान',
    'IT' => 'इटली',
    'JP' => 'जापान',
    'RU' => 'रूस',
    'US' => 'मूतहीद रियासत',
];
