<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AC' => 'Isla Ascensión',
    'AX' => 'Islas Åland',
    'CG' => 'República del Congo',
    'GG' => 'Guernsey',
    'GS' => 'Islas Georgia del Sur y Sándwich del Sur',
    'IC' => 'Islas Canarias',
    'RO' => 'Rumania',
    'SA' => 'Arabia Saudita',
    'SZ' => 'Eswatini',
    'TL' => 'Timor Oriental',
];
