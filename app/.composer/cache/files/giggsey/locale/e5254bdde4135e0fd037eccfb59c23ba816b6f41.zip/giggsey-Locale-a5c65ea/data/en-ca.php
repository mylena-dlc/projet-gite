<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AG' => 'Antigua and Barbuda',
    'BA' => 'Bosnia and Herzegovina',
    'BL' => 'Saint-Barthélemy',
    'EA' => 'Ceuta and Melilla',
    'GS' => 'South Georgia and South Sandwich Islands',
    'KN' => 'Saint Kitts and Nevis',
    'LC' => 'Saint Lucia',
    'MF' => 'Saint Martin',
    'PM' => 'Saint-Pierre-et-Miquelon',
    'PS' => 'Palestinian territories',
    'SH' => 'Saint Helena',
    'SJ' => 'Svalbard and Jan Mayen',
    'ST' => 'São Tomé and Príncipe',
    'TC' => 'Turks and Caicos Islands',
    'TT' => 'Trinidad and Tobago',
    'UM' => 'US Outlying Islands',
    'VC' => 'Saint Vincent and the Grenadines',
    'VI' => 'US Virgin Islands',
    'WF' => 'Wallis and Futuna',
];
