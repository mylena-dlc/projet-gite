<?php
/**
 * Locale data file
 * This file has been @generated from Locale data
 * Do not modify or use this file directly!
 * @internal
 */
return [
    'AF' => 'Afuganistani',
    'AZ' => 'Azabajani',
    'BJ' => 'Benini',
    'CI' => 'Kodivaa',
    'CX' => 'Kisiwa cha Christmas',
    'HR' => 'Kroeshia',
    'JO' => 'Yordani',
    'LB' => 'Lebanoni',
    'LI' => 'Lishenteni',
    'LU' => 'Lasembagi',
    'LV' => 'Lativia',
    'MA' => 'Moroko',
    'MM' => 'Myama',
    'NE' => 'Nijeri',
    'NG' => 'Nijeria',
    'NO' => 'Norwe',
    'NP' => 'Nepali',
    'OM' => 'Omani',
    'PR' => 'Puetoriko',
    'QA' => 'Katari',
    'SD' => 'Sudani',
    'ST' => 'Sao Tome na Prinsipe',
    'TD' => 'Chadi',
    'TL' => 'Timori ya Mashariki',
];
