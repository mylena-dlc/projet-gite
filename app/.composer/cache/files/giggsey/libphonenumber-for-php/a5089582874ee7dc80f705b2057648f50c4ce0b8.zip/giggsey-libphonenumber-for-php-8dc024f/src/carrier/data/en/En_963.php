<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_963
{
    public const DATA = [
        96350 => 'Rcell',
        96391 => 'Wafa Telecom',
        96392 => 'Wafa Telecom',
        96393 => 'Syriatel',
        96394 => 'MTN',
        96396 => 'MTN',
        96398 => 'Syriatel',
        96399 => 'Syriatel',
        963950 => 'MTN',
        963952 => 'MTN',
        963954 => 'MTN',
        963955 => 'MTN',
        963956 => 'MTN',
        963957 => 'MTN',
        963958 => 'MTN',
        963959 => 'MTN',
    ];
}
