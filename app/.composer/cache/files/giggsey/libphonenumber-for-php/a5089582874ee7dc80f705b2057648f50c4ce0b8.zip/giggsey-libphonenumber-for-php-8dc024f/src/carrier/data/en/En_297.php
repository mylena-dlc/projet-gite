<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_297
{
    public const DATA = [
        29729 => 'Digicel',
        29756 => 'SETAR',
        29759 => 'SETAR',
        29760 => 'SETAR',
        29762 => 'MIO Wireless',
        29763 => 'MIO Wireless',
        29764 => 'Digicel',
        29766 => 'SETAR',
        29773 => 'Digicel',
        29774 => 'Digicel',
        29777 => 'SETAR',
        297690 => 'SETAR',
        297699 => 'SETAR',
        297995 => 'SETAR',
    ];
}
