<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_508
{
    public const DATA = [
        50840 => 'Globaltel',
        50842 => 'Orange',
        50843 => 'Diabolocom',
        50844 => 'Globaltel',
        50850 => 'Keyyo',
        50855 => 'SPM Telecom',
        50856 => 'Kav El International',
        50870856 => 'SPM Telecom',
    ];
}
