<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_98
{
    public const DATA = [
        9890 => 'Irancell',
        9891 => 'IR-MCI',
        9892 => 'Rightel',
        9893 => 'Irancell',
        98931 => 'MTCE',
        98932 => 'Taliya',
        98934 => 'TeleKish',
        98990 => 'IR-MCI',
        98991 => 'IR-MCI',
        98994 => 'IR-MCI',
        98996 => 'IR-MCI',
        989981 => 'Shatel Mobile',
        989982 => 'Shatel Mobile',
        989991 => 'Irancell',
        989998 => 'Rightel',
        9899900 => 'LOTUSTEL',
        9899902 => 'IR-MCI',
        9899996 => 'Rightel',
        9899997 => 'Rightel',
        9899998 => 'Rightel',
        9899999 => 'Rightel',
    ];
}
