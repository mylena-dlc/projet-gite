<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_977
{
    public const DATA = [
        97790 => 'NCell',
        977960 => 'STM Telecom',
        977961 => 'Smart Telecom',
        977962 => 'Smart Telecom',
        977963 => 'NSTPL',
        977970 => 'NCell',
        977972 => 'UTL',
        977974 => 'NDCL',
        977975 => 'NDCL',
        977976 => 'Nepal Telecom',
        977980 => 'NCell',
        977981 => 'NCell',
        977982 => 'NCell',
        977984 => 'Nepal Telecom',
        977985 => 'Nepal Telecom',
        977986 => 'Nepal Telecom',
        977988 => 'Smart Telecom',
    ];
}
