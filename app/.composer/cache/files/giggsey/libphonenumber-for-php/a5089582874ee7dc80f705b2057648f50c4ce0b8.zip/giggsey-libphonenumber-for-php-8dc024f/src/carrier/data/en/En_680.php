<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_680
{
    public const DATA = [
        68045 => 'PMCI',
        68046 => 'PMCI',
        68077 => 'PalauCel',
        68078 => 'PalauCel',
        68083 => 'PMCI',
        68088 => 'PalauTel',
    ];
}
