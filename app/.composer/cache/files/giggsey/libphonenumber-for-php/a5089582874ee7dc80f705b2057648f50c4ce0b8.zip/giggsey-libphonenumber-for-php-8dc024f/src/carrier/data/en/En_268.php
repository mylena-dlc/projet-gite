<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_268
{
    public const DATA = [26876 => 'Swazi MTN', 'SPTC', 'Swazi MTN', 'Eswatini Mobile'];
}
