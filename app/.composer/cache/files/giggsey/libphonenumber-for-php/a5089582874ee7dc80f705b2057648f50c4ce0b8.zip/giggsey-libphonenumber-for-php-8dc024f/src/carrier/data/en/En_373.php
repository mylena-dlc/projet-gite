<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_373
{
    public const DATA = [
        37356 => 'IDC',
        37360 => 'Orange',
        37367 => 'Moldtelecom',
        37368 => 'Orange',
        37369 => 'Orange',
        37376 => 'Moldcell',
        37378 => 'Moldcell',
        37379 => 'Moldcell',
        373610 => 'Orange',
        373611 => 'Orange',
        373620 => 'Orange',
        373621 => 'Orange',
        373774 => 'IDC',
        373775 => 'IDC',
        373776 => 'IDC',
        373777 => 'IDC',
        373778 => 'IDC',
        373779 => 'IDC',
    ];
}
