<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_501
{
    public const DATA = [
        50160 => 'Belize Telemedia Ltd (Digi)',
        50161 => 'Belize Telemedia Ltd (Digi)',
        50162 => 'Belize Telemedia Ltd (Digi)',
        50163 => 'Belize Telemedia Ltd (Digi)',
        50165 => 'Speednet (Smart)',
        50166 => 'Speednet (Smart)',
        50167 => 'Speednet (Smart)',
    ];
}
