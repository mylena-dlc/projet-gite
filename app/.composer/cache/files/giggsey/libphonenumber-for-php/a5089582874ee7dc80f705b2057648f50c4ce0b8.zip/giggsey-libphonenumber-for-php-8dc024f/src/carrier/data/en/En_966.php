<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_966
{
    public const DATA = [
        96650 => 'STC',
        96653 => 'STC',
        96654 => 'Mobily',
        96655 => 'STC',
        96656 => 'Mobily',
        96658 => 'Zain',
        96659 => 'Zain',
        966510 => 'Salam',
        966511 => 'Salam',
        966570 => 'Virgin',
        966571 => 'Virgin',
        966572 => 'Virgin',
        966573 => 'Virgin',
        966574 => 'Red Bull Mobile',
        966575 => 'Red Bull Mobile',
        966576 => 'Lebara',
        966577 => 'Lebara',
        966578 => 'Lebara',
        966579 => 'Mobily',
        9665153 => 'STC',
        9665154 => 'STC',
    ];
}
