<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_673
{
    public const DATA = [
        67371 => 'UNN',
        67372 => 'UNN',
        67373 => 'UNN',
        67374 => 'UNN',
        67376 => 'UNN',
        67377 => 'UNN',
        67379 => 'UNN',
        67381 => 'UNN',
        67382 => 'UNN',
        67383 => 'UNN',
        67384 => 'UNN',
        67386 => 'UNN',
        67387 => 'UNN',
        67388 => 'UNN',
        67389 => 'UNN',
        673228 => 'DSTCom',
        673229 => 'DSTCom',
    ];
}
