<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_595
{
    public const DATA = [
        59595 => 'VOX',
        59596 => 'VOX',
        59597 => 'Personal',
        59599 => 'Claro',
        595981 => 'Tigo',
        595982 => 'Tigo',
        595983 => 'Tigo',
        595984 => 'Tigo',
        595985 => 'Tigo',
        595986 => 'Tigo',
        595987 => 'Tigo',
    ];
}
