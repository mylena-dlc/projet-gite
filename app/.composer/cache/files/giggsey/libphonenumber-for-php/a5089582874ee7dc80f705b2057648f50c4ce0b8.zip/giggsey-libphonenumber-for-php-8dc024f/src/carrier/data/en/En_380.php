<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_380
{
    public const DATA = [
        38039 => 'Kyivstar',
        38050 => 'Vodafone',
        38063 => 'lifecell',
        38066 => 'Vodafone',
        38067 => 'Kyivstar',
        38068 => 'Kyivstar',
        38073 => 'lifecell',
        38075 => 'Vodafone',
        38077 => 'Kyivstar',
        38079 => 'J&Y',
        38091 => 'TriMob',
        38092 => 'PEOPLEnet',
        38093 => 'lifecell',
        38094 => 'Intertelecom',
        38095 => 'Vodafone',
        38096 => 'Kyivstar',
        38097 => 'Kyivstar',
        38098 => 'Kyivstar',
        38099 => 'Vodafone',
    ];
}
