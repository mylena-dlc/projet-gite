<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_972
{
    public const DATA = [
        97250 => 'Pelephone',
        97251 => 'Xphone',
        97252 => 'Cellcom',
        97253 => 'Hot Mobile',
        97254 => 'Orange',
        97256 => 'Ooredoo',
        97258 => 'Golan Telecom',
        97259 => 'Jawwal',
        972510 => 'Wecom',
        972550 => 'Beezz',
        972552 => '019mobile',
        972556 => 'Rami Levy',
        972558 => 'Pelephone',
        972559 => '019mobile',
        9725520 => 'BITIT',
        9725521 => 'BITIT',
        9725522 => 'Home Cellular',
        9725523 => 'Home Cellular',
        9725530 => '019mobile',
        9725531 => '019mobile',
        9725532 => 'Free Telecom',
        9725533 => 'Free Telecom',
        9725540 => 'Rami Levy',
        9725541 => 'Merkaziya',
        9725543 => 'Maskyoo',
        9725544 => 'Cellran Cellular Communications',
        9725545 => 'Maskyoo',
        9725550 => 'Annatel',
        9725551 => 'Annatel',
        9725552 => 'Annatel',
        9725555 => 'Rami Levy',
        9725557 => 'Rami Levy',
        9725570 => 'Cellact',
        9725571 => 'Cellact',
        9725572 => 'Cellact',
        9725577 => '019mobile',
        97255440 => 'Merkaziya',
        97255442 => 'Xphone',
        97255443 => 'Yossi',
    ];
}
