<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_223
{
    public const DATA = [
        2235 => 'Atel',
        2236 => 'Sotelma',
        2237 => 'Orange',
        22382 => 'Orange',
        22383 => 'Orange',
        22384 => 'Orange',
        22385 => 'Orange',
        22389 => 'Sotelma',
        22390 => 'Orange',
        22391 => 'Orange',
        22392 => 'Orange',
        22393 => 'Orange',
        22394 => 'Orange',
        22395 => 'Sotelma',
        22396 => 'Sotelma',
        22397 => 'Sotelma',
        22398 => 'Sotelma',
        22399 => 'Sotelma',
        223200 => 'Orange',
        223217 => 'Sotelma',
        2232079 => 'Sotelma',
    ];
}
