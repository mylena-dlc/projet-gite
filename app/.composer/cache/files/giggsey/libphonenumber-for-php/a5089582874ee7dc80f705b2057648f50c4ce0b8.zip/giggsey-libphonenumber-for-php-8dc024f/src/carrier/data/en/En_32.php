<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_32
{
    public const DATA = [
        3247 => 'Proximus',
        3249 => 'Orange',
        32455 => 'VOO',
        32456 => 'Mobile Vikings/JIM Mobile',
        32460 => 'Proximus',
        32465 => 'Lycamobile',
        32468 => 'Telenet',
        32469 => 'Telenet',
        32483 => 'Telenet',
        32484 => 'Telenet',
        32485 => 'Telenet',
        32486 => 'Telenet',
        32487 => 'Telenet',
        32488 => 'Telenet',
        32489 => 'Telenet',
        324510 => 'DIGI Communications',
        324618 => 'N.M.B.S.',
        324630 => 'Lancelot Telecom',
        324631 => 'Lancelot Telecom',
        324650 => 'Telenet',
        324660 => 'Lycamobile',
        324661 => 'Lycamobile',
        324662 => 'Lycamobile',
        324663 => 'Lycamobile',
        324664 => 'Lycamobile',
        324665 => 'Vectone',
        324666 => 'Vectone',
        324667 => 'Vectone',
        324669 => 'Voxbone SA',
        324670 => 'Telenet',
        324671 => 'Join Experience Belgium',
        324672 => 'Join Experience Belgium',
        324674 => 'Febo Telecom',
        324676 => 'Lycamobile',
        324677 => 'Lycamobile',
        324678 => 'Lycamobile',
        324679 => 'Interactive Digital Media GmbH',
        324686 => 'OnOff Télécom SASU',
        324687 => 'Lancelot Telecom',
        324688 => 'Lancelot Telecom',
        324689 => 'Febo Telecom',
        324802 => 'TISMI BV',
        324803 => 'Lancelot Telecom',
        324805 => 'Voyacom SPRL',
        324806 => 'Telenet',
        324807 => 'MessageBird BV',
        324809 => 'Ericsson NV',
        3245001 => 'GATEWAY COMMUNICATIONS S.A.',
        32467306 => 'Telenet',
    ];
}
