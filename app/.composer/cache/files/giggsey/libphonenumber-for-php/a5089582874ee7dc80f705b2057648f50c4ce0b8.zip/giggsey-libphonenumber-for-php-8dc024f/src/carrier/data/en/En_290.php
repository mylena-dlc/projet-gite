<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_290
{
    public const DATA = [
        29051 => 'Sure South Atlantic Ltd',
        29052 => 'Sure South Atlantic Ltd',
        29053 => 'Sure South Atlantic Ltd',
        29054 => 'Sure South Atlantic Ltd',
        29055 => 'Sure South Atlantic Ltd',
        29056 => 'Sure South Atlantic Ltd',
        29057 => 'Sure South Atlantic Ltd',
        29058 => 'Sure South Atlantic Ltd',
        29061 => 'Sure South Atlantic Ltd',
        29062 => 'Sure South Atlantic Ltd',
        29063 => 'Sure South Atlantic Ltd',
        29064 => 'Sure South Atlantic Ltd',
        29065 => 'Sure South Atlantic Ltd',
        29066 => 'Sure South Atlantic Ltd',
        29067 => 'Sure South Atlantic Ltd',
        29068 => 'Sure South Atlantic Ltd',
    ];
}
