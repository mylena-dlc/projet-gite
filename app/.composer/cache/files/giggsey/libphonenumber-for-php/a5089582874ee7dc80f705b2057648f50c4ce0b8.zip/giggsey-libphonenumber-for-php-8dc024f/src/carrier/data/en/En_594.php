<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_594
{
    public const DATA = [
        5946940 => 'SFR',
        5946942 => 'Orange',
        5946943 => 'Orange',
        5946944 => 'Orange',
        5946949 => 'Digicel',
        59469408 => 'Digicel',
        59469409 => 'Digicel',
        59469412 => 'Digicel',
        59469413 => 'Digicel',
        59469414 => 'Digicel',
        59469415 => 'Digicel',
        59469416 => 'Digicel',
        59469417 => 'SFR',
        59469418 => 'SFR',
        59469419 => 'SFR',
        59469435 => 'Free Caraibe',
        59469436 => 'Free Caraibe',
        59469437 => 'Free Caraibe',
        59469446 => 'SFR',
        59469447 => 'SFR',
        59470930 => 'Free Caraibe',
        59470932 => 'Digicel',
        59470933 => 'Orange',
    ];
}
