<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_592
{
    public const DATA = [
        59261 => 'GTT',
        59262 => 'GTT',
        59264 => 'GTT',
        59265 => 'GTT',
        59266 => 'Digicel Guyana',
        59267 => 'Digicel Guyana',
        59268 => 'Digicel Guyana',
        59269 => 'Digicel Guyana',
        59271 => 'E-Networks',
        59273 => 'E-Networks',
        59274 => 'Digicel Guyana',
        59275 => 'GTT',
        59276 => 'E-Networks',
        592510 => 'Digicel Guyana',
        592600 => 'Digicel Guyana',
        592601 => 'Digicel Guyana',
        592602 => 'Digicel Guyana',
        592603 => 'Digicel Guyana',
        592604 => 'Digicel Guyana',
        592608 => 'Digicel Guyana',
        592609 => 'GTT',
        592630 => 'Digicel Guyana',
        592631 => 'Green Gibraltar',
        592632 => 'Digicel Guyana',
        592633 => 'Digicel Guyana',
        592634 => 'GTT',
        592635 => 'E-Networks',
        592636 => 'Digicel Guyana',
        592637 => 'Digicel Guyana',
        592638 => 'GTT',
        592639 => 'GTT',
        592659 => 'Digicel Guyana',
        592700 => 'Digicel Guyana',
        592701 => 'Digicel Guyana',
        592702 => 'Digicel Guyana',
        592703 => 'Digicel Guyana',
        592704 => 'Digicel Guyana',
        592705 => 'GTT',
        592706 => 'GTT',
        592707 => 'GTT',
        592708 => 'GTT',
        592709 => 'GTT',
        592720 => 'E-Networks',
        592721 => 'Digicel Guyana',
        592722 => 'Digicel Guyana',
        592723 => 'Digicel Guyana',
        592724 => 'Digicel Guyana',
        592725 => 'GTT',
        592726 => 'GTT',
        592727 => 'GTT',
        592728 => 'GTT',
        592729 => 'GTT',
        592740 => 'E-Networks',
        592741 => 'E-Networks',
        592742 => 'E-Networks',
        592750 => 'Digicel Guyana',
    ];
}
