<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_224
{
    public const DATA = [
        22460 => 'Sotelgui',
        22461 => 'Orange',
        22462 => 'Orange',
        22463 => 'Intercel',
        22465 => 'Cellcom',
        22466 => 'Areeba',
    ];
}
