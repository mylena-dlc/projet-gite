<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_231
{
    public const DATA = [
        2316 => 'Lonestar Cell',
        2317 => 'Orange',
        2318 => 'Lonestar Cell',
        23142 => 'Connect',
        231220 => 'Liberia Telecom',
        231330 => 'West Africa Telecom',
        231555 => 'Lonestar Cell',
    ];
}
