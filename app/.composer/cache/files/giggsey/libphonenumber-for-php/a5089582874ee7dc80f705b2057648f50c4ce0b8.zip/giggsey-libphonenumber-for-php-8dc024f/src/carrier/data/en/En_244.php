<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_244
{
    public const DATA = [
        24491 => 'Movicel',
        24492 => 'UNITEL',
        24493 => 'UNITEL',
        24494 => 'UNITEL',
        24495 => 'Africell',
        24496 => 'Africell',
        24497 => 'UNITEL',
        24499 => 'Movicel',
    ];
}
