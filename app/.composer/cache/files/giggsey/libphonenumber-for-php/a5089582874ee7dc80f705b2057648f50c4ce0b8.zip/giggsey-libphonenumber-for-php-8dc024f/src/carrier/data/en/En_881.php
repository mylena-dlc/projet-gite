<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_881
{
    public const DATA = [
        8810 => 'ico satellite',
        8811 => 'ico satellite',
        8812 => 'ellipso satellite',
        8813 => 'ellipso satellite',
        8816 => 'iridium satellite',
        8817 => 'iridium satellite',
        8818 => 'globalstar',
        8819 => 'globalstar',
    ];
}
