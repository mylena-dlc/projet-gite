<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_386
{
    public const DATA = [
        38630 => 'A1',
        38631 => 'Telekom Slovenije',
        38640 => 'A1',
        38641 => 'Telekom Slovenije',
        38643 => 'Telekom Slovenije',
        38649 => 'Telekom Slovenije',
        38651 => 'Telekom Slovenije',
        38664 => 'T-2',
        38668 => 'A1',
        38669 => 'A1',
        38670 => 'Telemach',
        38671 => 'Telemach',
        386651 => 'SŽ - Infrastruktura',
        386656 => 'SoftNet',
        386657 => 'Novatel',
        386658 => 'Novatel',
        386695 => 'Novatel',
        3866555 => 'Telekom Slovenije',
        3866556 => 'Sloexport',
        3866910 => 'Compatel',
    ];
}
