<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_504
{
    public const DATA = [5043 => 'Sercom (Claro)', 5047 => 'HONDUTEL', 5048 => 'Digicel Honduras', 5049 => 'Celtel (Tigo)'];
}
