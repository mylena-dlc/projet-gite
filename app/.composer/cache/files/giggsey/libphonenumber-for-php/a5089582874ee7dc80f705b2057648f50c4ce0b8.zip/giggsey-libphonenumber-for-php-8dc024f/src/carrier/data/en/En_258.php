<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_258
{
    public const DATA = [
        25882 => 'mcel',
        25883 => 'mcel',
        25884 => 'Vodacom',
        25885 => 'Vodacom',
        25886 => 'Movitel',
        25887 => 'Movitel',
        25889 => 'GMPCS',
    ];
}
