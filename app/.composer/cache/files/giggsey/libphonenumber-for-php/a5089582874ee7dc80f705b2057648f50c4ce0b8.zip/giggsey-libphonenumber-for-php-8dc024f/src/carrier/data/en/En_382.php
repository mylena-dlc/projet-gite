<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_382
{
    public const DATA = [
        38260 => 'm:tel',
        38263 => 'Telenor',
        38266 => 'Telekom',
        38267 => 'Telekom',
        38268 => 'm:tel',
        38269 => 'Telenor',
    ];
}
