<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_260
{
    public const DATA = [
        26075 => 'ZAMTEL',
        26076 => 'MTN',
        26077 => 'Airtel',
        26095 => 'ZAMTEL',
        26096 => 'MTN',
        26097 => 'Airtel',
        26098 => 'Beeline Telecoms',
    ];
}
