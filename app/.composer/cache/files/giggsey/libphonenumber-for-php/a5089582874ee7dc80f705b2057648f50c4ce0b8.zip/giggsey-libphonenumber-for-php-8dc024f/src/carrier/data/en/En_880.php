<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_880
{
    public const DATA = [
        88011 => 'Citycell',
        88013 => 'Grameenphone',
        88014 => 'Banglalink',
        88015 => 'TeleTalk',
        88016 => 'Robi',
        88017 => 'Grameenphone',
        88018 => 'Robi',
        88019 => 'Banglalink',
    ];
}
