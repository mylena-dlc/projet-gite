<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_265
{
    public const DATA = [
        2653 => 'TNM',
        2657 => 'Globally Advanced Integrated Networks Ltd',
        2658 => 'TNM',
        2659 => 'Airtel',
        26511 => 'Malawi Telecom-munications Ltd (MTL)',
    ];
}
