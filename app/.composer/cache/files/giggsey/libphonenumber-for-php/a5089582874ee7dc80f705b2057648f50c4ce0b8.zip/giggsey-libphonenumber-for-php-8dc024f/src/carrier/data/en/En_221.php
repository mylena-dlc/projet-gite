<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_221
{
    public const DATA = [
        22170 => 'Expresso',
        22171 => 'Orange',
        22172 => 'HAYO',
        22175 => 'Promobile',
        22176 => 'Free',
        22177 => 'Orange',
        22178 => 'Orange',
        22179 => 'ADIE',
        221757 => 'Origines',
        2217535 => 'Orange',
        2217536 => 'Orange',
        2217585 => 'Orange',
    ];
}
