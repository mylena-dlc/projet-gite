<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_218
{
    public const DATA = [
        21891 => 'Al-Madar',
        'Libyana',
        'Al-Madar',
        'Libyana',
        'Libya Telecom & Technology',
        'Libya Telecom & Technology',
    ];
}
