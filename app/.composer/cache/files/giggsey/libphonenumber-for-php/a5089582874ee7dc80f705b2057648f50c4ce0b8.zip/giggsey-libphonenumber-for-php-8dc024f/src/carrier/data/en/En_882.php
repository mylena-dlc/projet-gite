<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_882
{
    public const DATA = [
        88232 => 'Maritime Communications Partner (MCP)',
        88233 => 'Oration Technologies',
        88237 => 'AT&T Cingular Wireless Network',
        88249 => 'Monaco Telecom',
        88250 => 'Phonegroup',
        882342 => 'BebbiCell AG',
        882347 => 'BebbiCell AG',
    ];
}
