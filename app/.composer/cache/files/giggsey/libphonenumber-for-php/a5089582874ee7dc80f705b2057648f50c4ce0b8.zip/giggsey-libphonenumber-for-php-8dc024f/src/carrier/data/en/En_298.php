<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_298
{
    public const DATA = [
        2985 => 'Vodafone',
        2987 => 'Vodafone',
        29821 => 'Faroese Telecom',
        29822 => 'Faroese Telecom',
        29823 => 'Faroese Telecom',
        29824 => 'Faroese Telecom',
        29825 => 'Faroese Telecom',
        29826 => 'Faroese Telecom',
        29827 => 'Faroese Telecom',
        29828 => 'Faroese Telecom',
        29829 => 'Faroese Telecom',
        29878 => 'Faroese Telecom',
        29879 => 'Faroese Telecom',
        29891 => 'Faroese Telecom',
        29896 => 'Faroese Telecom',
    ];
}
