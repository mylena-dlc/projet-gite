<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_375
{
    public const DATA = [
        37525 => 'life:)',
        37533 => 'MTS',
        37544 => 'Velcom',
        375291 => 'Velcom',
        375292 => 'MTS',
        375293 => 'Velcom',
        375294 => 'Belcel',
        375295 => 'MTS',
        375296 => 'Velcom',
        375297 => 'MTS',
        375298 => 'MTS',
        375299 => 'Velcom',
    ];
}
