<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_63
{
    public const DATA = [
        6389 => 'Dito',
        6392 => 'Smart',
        6393 => 'Smart',
        6394 => 'Smart',
        6395 => 'Globe',
        6396 => 'Smart',
        63813 => 'Smart',
        63905 => 'Globe',
        63906 => 'Globe',
        63907 => 'Smart',
        63908 => 'Smart',
        63909 => 'Smart',
        63910 => 'Smart',
        63911 => 'Smart',
        63912 => 'Smart',
        63914 => 'Globe',
        63915 => 'Globe',
        63916 => 'Globe',
        63917 => 'Globe',
        63918 => 'Smart',
        63919 => 'Smart',
        63924 => 'Dito',
        63926 => 'Globe',
        63927 => 'Globe',
        63934 => 'Dito',
        63935 => 'Globe',
        63936 => 'Globe',
        63937 => 'Globe',
        63944 => 'Dito',
        63945 => 'Globe',
        63950 => 'Smart',
        63951 => 'Smart',
        63958 => 'Smart',
        63965 => 'Globe',
        63966 => 'Globe',
        63967 => 'Globe',
        63970 => 'Smart',
        63971 => 'Globe',
        63972 => 'Globe',
        63975 => 'Globe',
        63976 => 'Globe',
        63977 => 'Globe',
        63978 => 'Globe',
        63981 => 'Smart',
        63983 => 'Globe',
        63985 => 'Smart',
        63986 => 'Globe',
        63987 => 'Globe',
        63988 => 'Smart',
        63991 => 'Dito',
        63992 => 'Dito',
        63993 => 'Dito',
        63994 => 'Dito',
        63995 => 'Globe',
        63996 => 'Globe',
        63997 => 'Globe',
        63998 => 'Smart',
        63999 => 'Smart',
    ];
}
