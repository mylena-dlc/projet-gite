<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\ru;

/**
 * @internal
 */
class Ru_375
{
    public const DATA = [
        37533 => 'МТС',
        375292 => 'МТС',
        375294 => 'БелСел',
        375295 => 'МТС',
        375297 => 'МТС',
        375298 => 'МТС',
    ];
}
