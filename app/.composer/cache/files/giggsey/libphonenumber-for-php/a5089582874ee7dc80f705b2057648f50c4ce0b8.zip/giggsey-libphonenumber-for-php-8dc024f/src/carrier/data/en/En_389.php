<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_389
{
    public const DATA = [
        38970 => 'T-Mobile',
        38971 => 'T-Mobile',
        38972 => 'T-Mobile',
        38973 => 'A1',
        38975 => 'A1',
        38976 => 'A1',
        38977 => 'A1',
        38978 => 'A1',
        389736 => 'T-Mobile',
        389742 => 'T-Mobile',
        389746 => 'T-Mobile',
        389790 => 'A1',
        389791 => 'A1',
        389792 => 'Lyca Mobile',
        389793 => 'Lyca Mobile',
        389794 => 'Lyca Mobile',
        389795 => 'Lyca Mobile',
        389799 => 'A1',
        3897421 => 'Mobik',
        3897470 => 'T-Mobile',
        3897471 => 'T-Mobile',
        3897474 => 'T-Mobile',
        3897475 => 'A1',
        3897477 => 'A1',
        3897478 => 'A1',
        3897970 => 'T-Mobile',
        3897971 => 'T-Mobile',
        3897975 => 'A1',
        38974774 => 'Telekabel',
    ];
}
