<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_351
{
    public const DATA = [
        3511 => 'NOS',
        35191 => 'Vodafone',
        35193 => 'NOS',
        35196 => 'MEO',
        351921 => 'Vodafone',
        351923 => 'NOS',
        351924 => 'MEO',
        351925 => 'MEO',
        351926 => 'MEO',
        351927 => 'MEO',
        3516093 => 'NOS',
        3516393 => 'NOS',
        3516593 => 'NOS',
        3516693 => 'NOS',
        3519200 => 'Lycamobile',
        3519201 => 'Lycamobile',
        3519202 => 'Lycamobile',
        3519203 => 'Lycamobile',
        3519204 => 'Lycamobile',
        3519205 => 'Lycamobile',
        3519208 => 'Lycamobile',
        3519220 => 'Vodafone',
        3519221 => 'MEO',
        3519222 => 'MEO',
        3519231 => 'Vodafone',
        3519232 => 'MEO',
        3519233 => 'Digi Communications',
        3519234 => 'G9 Telecom',
        3519280 => 'MEO',
        3519281 => 'MEO',
        3519282 => 'Digi Communications',
        3519283 => 'Digi Communications',
        3519284 => 'Digi Communications',
        3519285 => 'MEO',
        3519290 => 'NOS',
        3519291 => 'NOS',
        3519292 => 'NOS',
        3519293 => 'NOS',
        3519294 => 'NOS',
        3519295 => 'Sumamovil Portugal',
        35160929 => 'NOS',
        35163920 => 'Lycamobile',
        35163924 => 'MEO',
        35163929 => 'NOS',
        35165920 => 'Lycamobile',
        35165924 => 'MEO',
        35165929 => 'NOS',
        35166929 => 'NOS',
        351609230 => 'NOS',
        351639230 => 'NOS',
        351639233 => 'Digi Communications',
        351639234 => 'G9 Telecom',
        351659230 => 'NOS',
        351659233 => 'Digi Communications',
        351659234 => 'G9 Telecom',
        351669230 => 'NOS',
    ];
}
