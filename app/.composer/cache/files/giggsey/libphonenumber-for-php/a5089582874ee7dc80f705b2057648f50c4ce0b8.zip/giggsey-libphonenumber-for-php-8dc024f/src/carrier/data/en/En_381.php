<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_381
{
    public const DATA = [
        38160 => 'A1',
        38161 => 'A1',
        38162 => 'Telenor',
        38163 => 'Telenor',
        38164 => 'Telekom Srbija a.d.',
        38165 => 'Telekom Srbija a.d.',
        38166 => 'Telekom Srbija a.d.',
        38168 => 'A1',
        38169 => 'Telenor',
        381676 => 'GLOBALTEL',
        381677 => 'GLOBALTEL',
        381678 => 'Vectone Mobile',
    ];
}
