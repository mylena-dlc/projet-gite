<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\ar;

/**
 * @internal
 */
class Ar_965
{
    public const DATA = [9655 => 'فيفا', 9656 => 'أوريدو', 9659 => 'زين'];
}
