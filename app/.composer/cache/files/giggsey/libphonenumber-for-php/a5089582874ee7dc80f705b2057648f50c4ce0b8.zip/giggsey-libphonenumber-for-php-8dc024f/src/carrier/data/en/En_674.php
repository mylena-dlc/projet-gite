<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_674
{
    public const DATA = [
        6746 => 'Digicel',
        6748 => 'FSM Telecom',
        674553 => 'Digicel',
        674554 => 'Digicel',
        674556 => 'Digicel',
        674557 => 'Digicel',
        674558 => 'Digicel',
        674559 => 'Digicel',
    ];
}
