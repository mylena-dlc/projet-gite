<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_220
{
    public const DATA = [
        2202 => 'Africell',
        2203 => 'QCell',
        2206 => 'Comium',
        2207 => 'Africell',
        2209 => 'Gamcel',
        22040 => 'Africell',
        22041 => 'Africell',
        22045 => 'Africell',
        22050 => 'QCell',
        22051 => 'QCell',
        22052 => 'QCell',
        22053 => 'QCell',
        22054 => 'QCell',
        22058 => 'QCell',
        22059 => 'QCell',
    ];
}
