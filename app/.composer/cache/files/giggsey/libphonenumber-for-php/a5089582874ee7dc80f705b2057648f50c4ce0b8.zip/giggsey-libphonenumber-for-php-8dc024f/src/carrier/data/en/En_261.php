<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_261
{
    public const DATA = [
        26132 => 'Orange',
        26133 => 'Airtel',
        26134 => 'Telma',
        26137 => 'Orange',
        26138 => 'Telma',
        26139 => 'Blueline',
    ];
}
