<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_248
{
    public const DATA = [
        24821 => 'Intelvision',
        24822 => 'Intelvision',
        24825 => 'CWS',
        24826 => 'CWS',
        24827 => 'Airtel',
        24828 => 'Airtel',
    ];
}
