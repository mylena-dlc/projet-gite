<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_216
{
    public const DATA = [
        2162 => 'Ooredoo',
        2164 => 'Tunisie Telecom',
        2165 => 'Orange',
        2169 => 'Tunisie Telecom',
        21645 => 'Watany Ettisalat',
        21646 => 'Ooredoo',
        21648 => 'Ooredoo',
    ];
}
