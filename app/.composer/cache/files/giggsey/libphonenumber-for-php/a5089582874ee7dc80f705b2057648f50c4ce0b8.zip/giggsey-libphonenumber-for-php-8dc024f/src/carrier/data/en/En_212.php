<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_212
{
    public const DATA = [
        21260 => 'Inwi',
        21261 => 'Maroc Telecom',
        21265 => 'Maroc Telecom',
        21267 => 'Maroc Telecom',
        21270 => 'Inwi',
        21271 => 'Inwi',
        21272 => 'Inwi',
        21275 => 'Maroc Telecom',
        21276 => 'Maroc Telecom',
        21277 => 'Orange',
        21278 => 'Orange',
        212612 => 'Orange',
        212614 => 'Orange',
        212617 => 'Orange',
        212619 => 'Orange',
        212620 => 'Orange',
        212621 => 'Orange',
        212622 => 'Maroc Telecom',
        212623 => 'Maroc Telecom',
        212624 => 'Maroc Telecom',
        212625 => 'Orange',
        212626 => 'Inwi',
        212627 => 'Inwi',
        212628 => 'Maroc Telecom',
        212629 => 'Inwi',
        212630 => 'Inwi',
        212631 => 'Orange',
        212632 => 'Orange',
        212633 => 'Inwi',
        212634 => 'Inwi',
        212635 => 'Inwi',
        212636 => 'Maroc Telecom',
        212637 => 'Maroc Telecom',
        212638 => 'Inwi',
        212639 => 'Maroc Telecom',
        212640 => 'Inwi',
        212641 => 'Maroc Telecom',
        212642 => 'Maroc Telecom',
        212643 => 'Maroc Telecom',
        212644 => 'Orange',
        212645 => 'Orange',
        212646 => 'Inwi',
        212647 => 'Inwi',
        212648 => 'Maroc Telecom',
        212649 => 'Orange',
        212656 => 'Orange',
        212657 => 'Orange',
        212660 => 'Orange',
        212661 => 'Maroc Telecom',
        212662 => 'Maroc Telecom',
        212663 => 'Orange',
        212664 => 'Orange',
        212665 => 'Orange',
        212666 => 'Maroc Telecom',
        212667 => 'Maroc Telecom',
        212668 => 'Maroc Telecom',
        212669 => 'Orange',
        212674 => 'Orange',
        212675 => 'Orange',
        212679 => 'Orange',
        212680 => 'Inwi',
        212681 => 'Inwi',
        212682 => 'Maroc Telecom',
        212684 => 'Orange',
        212687 => 'Inwi',
        212688 => 'Orange',
        212689 => 'Maroc Telecom',
        212690 => 'Inwi',
        212691 => 'Orange',
        212693 => 'Orange',
        212694 => 'Orange',
        212695 => 'Inwi',
        212696 => 'Maroc Telecom',
        212697 => 'Maroc Telecom',
        212698 => 'Inwi',
        212699 => 'Inwi',
        2126921 => 'Al Hourria Telecom',
        2126922 => 'Al Hourria Telecom',
    ];
}
