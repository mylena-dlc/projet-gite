<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_39
{
    public const DATA = [
        3932 => 'WIND',
        3933 => 'TIM',
        3934 => 'Vodafone',
        3936 => 'TIM',
        3938 => 'WIND',
        3939 => '3 Italia',
        39319 => 'Intermatica',
        39370 => 'TIM',
        39371 => 'Vodafone',
        39373 => '3 Italia',
        39377 => 'Vodafone',
        39383 => 'Vodafone',
        393780 => 'spusu',
        393784 => 'Vodafone',
    ];
}
