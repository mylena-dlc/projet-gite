<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_591
{
    public const DATA = [
        5916 => 'Tigo',
        5917 => 'Tigo',
        59174 => 'Entel',
        5917419 => 'Nuevatel',
        5917429 => 'Nuevatel',
        5917438 => 'Nuevatel',
        5917439 => 'Nuevatel',
        5917449 => 'Nuevatel',
        5917459 => 'Nuevatel',
        5917474 => 'Nuevatel',
        5917479 => 'Nuevatel',
        5917487 => 'Nuevatel',
        5917488 => 'Nuevatel',
        5917489 => 'Nuevatel',
        5917497 => 'Nuevatel',
        5917498 => 'Nuevatel',
        5917499 => 'Nuevatel',
    ];
}
