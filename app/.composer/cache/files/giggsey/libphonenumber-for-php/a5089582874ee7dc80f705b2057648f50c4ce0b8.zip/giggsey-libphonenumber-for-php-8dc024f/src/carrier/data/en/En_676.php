<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_676
{
    public const DATA = [
        6769 => 'Digicel',
        67654 => 'Toko Wireless',
        67668 => 'Digicel',
        67670 => 'Digicel',
        67672 => 'U-Call Tonga',
        67673 => 'U-Call Tonga',
        67674 => 'U-Call Tonga',
        67675 => 'U-Call Tonga',
        67676 => 'U-Call Tonga',
        67677 => 'U-Call Tonga',
        67678 => 'U-Call Tonga',
        67679 => 'U-Call Tonga',
        67684 => 'Digicel',
        67686 => 'Digicel',
        67687 => 'Digicel',
        67688 => 'Digicel',
        67689 => 'Digicel',
        676554 => 'Toko Wireless',
        676555 => 'Toko Wireless',
        676556 => 'Toko Wireless',
    ];
}
