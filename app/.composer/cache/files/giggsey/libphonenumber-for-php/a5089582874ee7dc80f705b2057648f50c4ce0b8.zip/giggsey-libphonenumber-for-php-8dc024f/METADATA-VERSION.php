<?php

declare(strict_types=1);

/**
 * This file specifies the revision of the metadata to build from.
 * It can be a commit, branch or tag of the https://github.com/google/libphonenumber project
 * For more information, look at the phing tasks in build.xml
 * @internal
 */
return 'v9.0.0';
