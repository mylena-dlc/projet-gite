<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_971
{
    public const DATA = [
        97150 => 'Etisalat',
        97152 => 'du',
        97154 => 'Etisalat',
        97155 => 'du',
        97156 => 'Etisalat',
        97158 => 'du',
    ];
}
