<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_62
{
    public const DATA = [
        62811 => 'Telkomsel',
        62812 => 'Telkomsel',
        62813 => 'Telkomsel',
        62814 => 'Indosat Ooredoo Hutchison',
        62815 => 'Indosat Ooredoo Hutchison',
        62816 => 'Indosat Ooredoo Hutchison',
        62817 => 'XL',
        62818 => 'XL',
        62819 => 'XL',
        62821 => 'Telkomsel',
        62822 => 'Telkomsel',
        62823 => 'Telkomsel',
        62831 => 'AXIS',
        62832 => 'AXIS',
        62833 => 'AXIS',
        62838 => 'AXIS',
        62851 => 'Telkomsel',
        62852 => 'Telkomsel',
        62853 => 'Telkomsel',
        62855 => 'Indosat Ooredoo Hutchison',
        62856 => 'Indosat Ooredoo Hutchison',
        62857 => 'Indosat Ooredoo Hutchison',
        62858 => 'Indosat Ooredoo Hutchison',
        62859 => 'XL',
        62877 => 'XL',
        62878 => 'XL',
        62879 => 'XL',
        62881 => 'Smartfren',
        62882 => 'Smartfren',
        62883 => 'Smartfren',
        62887 => 'Smartfren',
        62888 => 'Smartfren',
        62889 => 'Smartfren',
        62895 => 'Indosat Ooredoo Hutchison',
        62896 => 'Indosat Ooredoo Hutchison',
        62897 => 'Indosat Ooredoo Hutchison',
        62898 => 'Indosat Ooredoo Hutchison',
        62899 => 'Indosat Ooredoo Hutchison',
    ];
}
