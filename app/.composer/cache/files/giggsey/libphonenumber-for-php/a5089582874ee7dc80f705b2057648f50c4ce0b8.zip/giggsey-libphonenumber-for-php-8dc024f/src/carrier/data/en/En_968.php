<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_968
{
    public const DATA = [
        9681 => 'Ooredoo',
        96871 => 'Omantel',
        96872 => 'Omantel',
        96876 => 'Vodafone Oman',
        96877 => 'Vodafone Oman',
        96878 => 'Ooredoo',
        96891 => 'Omantel',
        96892 => 'Omantel',
        96893 => 'Omantel',
        96894 => 'Ooredoo',
        96895 => 'Ooredoo',
        96896 => 'Ooredoo',
        96897 => 'Ooredoo',
        96898 => 'Omantel',
        96899 => 'Omantel',
        968790 => 'Ooredoo',
        968791 => 'Ooredoo',
        968792 => 'Ooredoo',
        968793 => 'Ooredoo',
        968794 => 'Ooredoo',
        968795 => 'Ooredoo',
        968796 => 'Ooredoo',
        968901 => 'Omantel',
        968902 => 'Omantel',
        968903 => 'Omantel',
        968904 => 'Omantel',
        968905 => 'Omantel',
        968906 => 'Omantel',
        968907 => 'Omantel',
        968908 => 'Omantel',
        968909 => 'Omantel',
    ];
}
