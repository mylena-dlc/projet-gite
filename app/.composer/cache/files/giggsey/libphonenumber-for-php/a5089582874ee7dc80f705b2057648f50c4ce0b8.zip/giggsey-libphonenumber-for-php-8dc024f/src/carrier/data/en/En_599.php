<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_599
{
    public const DATA = [
        59970 => 'Digicel',
        59977 => 'Kla',
        59978 => 'Digicel',
        59979 => 'Chippie',
        59996 => 'Digicel',
        599319 => 'WIC',
        599951 => 'Chippie',
        599952 => 'Chippie',
        599953 => 'Chippie',
        599954 => 'Chippie',
        599956 => 'Chippie',
        599957 => 'Antelecom',
        5993181 => 'Telcell',
        5993184 => 'Telcell',
        5993185 => 'Telcell',
        5993186 => 'Telcell',
        5993187 => 'Telcell',
        5993188 => 'Telcell',
        5994161 => 'Telcell',
        5994164 => 'WIC',
        5994165 => 'WIC',
        5994166 => 'WIC',
        5994167 => 'WIC',
        5994168 => 'WIC',
        5994169 => 'Satel',
    ];
}
