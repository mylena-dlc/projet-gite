<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_677
{
    public const DATA = [
        6777 => 'Solomon Telekom',
        6778 => 'BMobile',
        6779 => 'Smile',
        67768 => 'Satsol',
        67769 => 'Satsol',
        67791 => 'Satsol',
        67792 => 'Satsol',
        67793 => 'Satsol',
    ];
}
