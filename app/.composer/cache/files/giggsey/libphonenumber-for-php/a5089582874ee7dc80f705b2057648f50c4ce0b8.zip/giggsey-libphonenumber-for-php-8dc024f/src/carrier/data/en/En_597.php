<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_597
{
    public const DATA = [
        5978 => 'Telesur',
        59771 => 'Digicel',
        59772 => 'Digicel',
        59774 => 'Digicel',
        59775 => 'Telesur',
        59776 => 'Digicel',
        59777 => 'Telesur',
        59781 => 'Digicel',
        59782 => 'Digicel',
        59783 => 'Digicel',
    ];
}
