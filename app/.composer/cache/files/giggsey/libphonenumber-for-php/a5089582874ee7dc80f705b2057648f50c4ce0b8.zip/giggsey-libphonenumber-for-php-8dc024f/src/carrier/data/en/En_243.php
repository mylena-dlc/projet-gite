<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_243
{
    public const DATA = [
        24380 => 'Orange',
        24381 => 'Vodacom',
        24382 => 'Vodacom',
        24383 => 'Vodacom',
        24384 => 'Orange',
        24385 => 'Orange',
        24386 => 'Vodacom',
        24388 => 'Yozma Timeturns sprl -YTT',
        24389 => 'Orange',
        24390 => 'Africell',
        24391 => 'Africell',
        24397 => 'Airtel',
        24398 => 'Airtel',
        24399 => 'Airtel',
    ];
}
