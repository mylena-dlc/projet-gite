<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_230
{
    public const DATA = [
        23054 => 'Emtel',
        23055 => 'Emtel',
        23057 => 'Cellplus',
        230525 => 'Cellplus',
        230526 => 'Cellplus',
        230527 => 'MTML',
        230528 => 'MTML',
        230529 => 'MTML',
        230550 => 'Cellplus',
        230552 => 'MTML',
        230553 => 'Cellplus',
        230571 => 'Emtel',
        230572 => 'Emtel',
        230573 => 'Emtel',
        230574 => 'Emtel',
        230580 => 'Cellplus',
        230581 => 'Cellplus',
        230582 => 'Cellplus',
        230583 => 'Cellplus',
        230584 => 'Emtel',
        230585 => 'Emtel',
        230586 => 'MTML',
        230588 => 'MTML',
        230589 => 'MTML',
        230590 => 'Cellplus',
        230591 => 'Cellplus',
        230592 => 'Cellplus',
        230593 => 'Emtel',
        230594 => 'Cellplus',
        230595 => 'MTML',
        230596 => 'MTML',
        230597 => 'Emtel',
        230598 => 'Emtel',
        230700 => 'Cellplus',
        230701 => 'Emtel',
        230702 => 'MTML',
        230703 => 'Emtel',
        230704 => 'Emtel',
        230730 => 'Emtel',
        230731 => 'MTML',
        230733 => 'Cellplus',
        2305471 => 'Cellplus',
        2305871 => 'MTML',
        2305875 => 'Cellplus',
        2305876 => 'Cellplus',
        2305877 => 'Cellplus',
        2305878 => 'Cellplus',
    ];
}
