<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_976
{
    public const DATA = [
        97650 => 'Unitel',
        97655 => 'Unitel',
        97660 => 'ONDO',
        97666 => 'ONDO',
        97669 => 'Skytel',
        97672 => 'Lime',
        97680 => 'Unitel',
        97681 => 'ONDO',
        97683 => 'G-Mobile',
        97685 => 'Mobicom',
        97686 => 'Unitel',
        97688 => 'Unitel',
        97689 => 'Unitel',
        97690 => 'Skytel',
        97691 => 'Skytel',
        97692 => 'Skytel',
        97693 => 'G-Mobile',
        97694 => 'Mobicom',
        97695 => 'Mobicom',
        97696 => 'Skytel',
        97697 => 'G-Mobile',
        97698 => 'G-Mobile',
        97699 => 'Mobicom',
    ];
}
