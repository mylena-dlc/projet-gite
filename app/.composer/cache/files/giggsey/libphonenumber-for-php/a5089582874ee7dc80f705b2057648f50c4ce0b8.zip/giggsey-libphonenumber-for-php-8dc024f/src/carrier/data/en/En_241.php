<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_241
{
    public const DATA = [
        2413 => 'Libertis',
        2414 => 'Airtel',
        2415 => 'Moov',
        2416 => 'Libertis',
        2417 => 'Airtel',
        24104 => 'Airtel',
        24105 => 'Moov',
        24106 => 'Libertis',
        24107 => 'Airtel',
        24120 => 'Libertis',
        24121 => 'Libertis',
        24122 => 'Libertis',
        24123 => 'Libertis',
        24124 => 'Libertis',
        24125 => 'Libertis',
        24126 => 'Libertis',
        24127 => 'Libertis',
        24165 => 'Moov',
    ];
}
