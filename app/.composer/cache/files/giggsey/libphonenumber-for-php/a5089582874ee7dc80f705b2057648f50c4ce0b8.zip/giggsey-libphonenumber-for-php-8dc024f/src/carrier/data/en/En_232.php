<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_232
{
    public const DATA = [
        2326 => 'Onlime',
        2327 => 'Orange',
        2328 => 'Africell',
        2329 => 'Africell',
        23225 => 'Sierratel',
        23230 => 'Africell',
        23231 => 'QCELL',
        23232 => 'QCELL',
        23233 => 'Africell',
        23234 => 'QCELL',
        23235 => 'IPTEL',
        23277 => 'Africell',
    ];
}
