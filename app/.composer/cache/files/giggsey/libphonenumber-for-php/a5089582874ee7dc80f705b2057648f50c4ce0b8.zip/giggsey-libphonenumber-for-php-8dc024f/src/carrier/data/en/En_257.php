<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_257
{
    public const DATA = [
        2576 => 'Viettel',
        25729 => 'Leo',
        25771 => 'Leo',
        25772 => 'Leo',
        25775 => 'Smart Mobile',
        25776 => 'Leo',
        25777 => 'Onatel',
        25778 => 'Smart Mobile',
        25779 => 'Leo',
    ];
}
