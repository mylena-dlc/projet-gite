<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_255
{
    public const DATA = [
        25561 => 'Viettel',
        25562 => 'Viettel',
        25565 => 'tiGO',
        25566 => 'SMILE',
        25567 => 'tiGO',
        25568 => 'Airtel',
        25569 => 'Airtel',
        25571 => 'tiGO',
        25573 => 'Tanzania Telecom',
        25574 => 'Vodacom',
        25575 => 'Vodacom',
        25576 => 'Vodacom',
        25577 => 'tiGO',
        25578 => 'Airtel',
        25579 => 'Vodacom',
    ];
}
