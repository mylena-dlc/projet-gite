<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_964
{
    public const DATA = [
        96473 => 'ITPC',
        96475 => 'Korek',
        96476 => 'Omnnea',
        96477 => 'Asiacell',
        96478 => 'Zain',
        96479 => 'Zain',
        9647400 => 'Itisaluna',
        9647401 => 'Itisaluna',
        9647435 => 'Kalimat',
        9647436 => 'Kalimat',
        9647444 => 'Mobitel',
        9647480 => 'ITC Fanoos',
        9647481 => 'ITC Fanoos',
        9647491 => 'ITPC',
        9647494 => 'Imam Hussien Holy Shrine',
        9647495 => 'IraqTel',
        9647496 => 'IraqTel',
    ];
}
