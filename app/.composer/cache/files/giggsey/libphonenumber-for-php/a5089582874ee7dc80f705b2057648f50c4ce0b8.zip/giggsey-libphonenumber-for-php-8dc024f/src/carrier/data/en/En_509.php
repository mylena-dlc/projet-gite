<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_509
{
    public const DATA = [
        5093 => 'Digicel',
        5095 => 'Natcom',
        50932 => 'Natcom',
        50933 => 'Natcom',
        50935 => 'Natcom',
        50940 => 'Natcom',
        50941 => 'Natcom',
        50942 => 'Natcom',
        50943 => 'Natcom',
        50944 => 'Digicel',
        50946 => 'Digicel',
        50947 => 'Digicel',
        50948 => 'Digicel',
        50949 => 'Digicel',
    ];
}
