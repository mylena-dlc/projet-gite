<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_383
{
    public const DATA = [
        38343 => 'IPKO',
        38344 => 'vala',
        38347 => 'mts d.o.o.',
        38348 => 'IPKO',
        38349 => 'IPKO',
        383451 => 'vala',
        383452 => 'vala',
        383453 => 'vala',
        383454 => 'vala',
        383455 => 'Z Mobile',
        383456 => 'Z Mobile',
        383457 => 'vala',
        383458 => 'vala',
        383459 => 'vala',
        383461 => 'vala',
        383462 => 'vala',
        383463 => 'vala',
        383464 => 'vala',
        383465 => 'vala',
        383466 => 'vala',
        383467 => 'vala',
        383468 => 'vala',
        383469 => 'vala',
    ];
}
