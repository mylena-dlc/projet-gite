<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_252
{
    public const DATA = [
        2529 => 'STG',
        25224 => 'Telesom',
        25228 => 'Nationlink',
        25235 => 'AirSom',
        25239 => 'AirSom',
        25248 => 'AirSom',
        25249 => 'AirSom',
        25260 => 'Golis Telecom',
        25261 => 'Hormuud',
        25262 => 'Somtel',
        25263 => 'Telesom',
        25264 => 'Somali Networks',
        25265 => 'Somtel',
        25266 => 'Somtel',
        25267 => 'Nationlink',
        25268 => 'SomNet',
        25269 => 'Nationlink',
        25270 => 'Golis Telecom',
        25271 => 'Amtel',
        25272 => 'Golis Telecom',
        25276 => 'Somtel',
        25279 => 'Somtel',
        25280 => 'Somali Networks',
        25288 => 'Somali Networks',
        25290 => 'Golis Telecom',
    ];
}
