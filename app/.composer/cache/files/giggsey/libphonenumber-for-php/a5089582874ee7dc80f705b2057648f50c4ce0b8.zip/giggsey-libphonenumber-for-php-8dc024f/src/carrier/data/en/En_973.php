<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_973
{
    public const DATA = [
        97330 => 'Telecommunications Regulatory Authority',
        97331 => 'Royal Court',
        97332 => 'Batelco',
        97333 => 'VIVA',
        97334 => 'VIVA',
        97335 => 'VIVA',
        97336 => 'zain BH',
        97337 => 'zain BH',
        97338 => 'Batelco',
        97339 => 'Batelco',
        97363 => 'VIVA',
        97364 => 'Batelco',
        973385 => 'Telecommunications Regulatory Authority',
        973666 => 'zain BH',
        973669 => 'zain BH',
        9736630 => 'zain BH',
        9736633 => 'zain BH',
        9736634 => 'zain BH',
        9736635 => 'zain BH',
        9736636 => 'zain BH',
        9736637 => 'zain BH',
        9736638 => 'zain BH',
        9736639 => 'zain BH',
        9736670 => 'Batelco',
        9736671 => 'Batelco',
        9736672 => 'Batelco',
        9736673 => 'Batelco',
        9736674 => 'Batelco',
        9736675 => 'Batelco',
        9736676 => 'Batelco',
        9736678 => 'Batelco',
        9736679 => 'Batelco',
    ];
}
