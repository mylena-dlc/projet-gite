<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_93
{
    public const DATA = [
        9370 => 'AWCC',
        9371 => 'AWCC',
        9372 => 'Roshan',
        9373 => 'Etisalat',
        9375 => 'Afghan Telecom',
        9376 => 'MTN',
        9377 => 'MTN',
        9378 => 'Etisalat',
        9379 => 'Roshan',
        93744 => 'Afghan Telecom',
        93747 => 'Afghan Telecom',
        93748 => 'Afghan Telecom',
        93749 => 'Afghan Telecom',
    ];
}
