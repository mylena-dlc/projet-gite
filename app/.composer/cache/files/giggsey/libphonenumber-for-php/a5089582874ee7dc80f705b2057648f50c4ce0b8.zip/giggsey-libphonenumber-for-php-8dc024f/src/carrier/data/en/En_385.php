<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_385
{
    public const DATA = [
        38590 => 'Tele2',
        38591 => 'A1 Telekom',
        38592 => 'A1 Telekom',
        38595 => 'Tele2',
        38598 => 'Hrvatski Telekom',
        38599 => 'Hrvatski Telekom',
        385970 => 'Hrvatski Telekom',
        385976 => 'Hrvatski Telekom',
        385977 => 'Hrvatski Telekom',
        385979 => 'Hrvatski Telekom',
        3859750 => 'Lancelot Telecom',
        3859751 => 'Telefocus',
        3859754 => 'Lancelot Telecom',
        3859755 => 'BSG',
        3859757 => 'Mobile One',
        38597595 => 'YATECO',
        38597596 => 'Altavox',
        38597597 => 'INNOVAC',
        38597599 => 'Digicom',
    ];
}
