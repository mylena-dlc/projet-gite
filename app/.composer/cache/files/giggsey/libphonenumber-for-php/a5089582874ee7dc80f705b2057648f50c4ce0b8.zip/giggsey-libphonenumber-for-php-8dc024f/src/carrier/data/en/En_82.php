<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_82
{
    public const DATA = [
        8211 => 'SKTellink',
        8216 => 'KT',
        8217 => 'SKTellink',
        8218 => 'KT',
        8219 => 'LG U+',
        82100 => 'LG U+',
        82104 => 'SKTellink',
        82122 => 'KT',
        821020 => 'SKTellink',
        821021 => 'SKTellink',
        821022 => 'LG U+',
        821023 => 'LG U+',
        821024 => 'LG U+',
        821025 => 'KT',
        821026 => 'KT',
        821027 => 'KT',
        821028 => 'KT',
        821029 => 'KT',
        821030 => 'KT',
        821031 => 'SKTellink',
        821032 => 'KT',
        821033 => 'KT',
        821034 => 'KT',
        821035 => 'SKTellink',
        821036 => 'SKTellink',
        821037 => 'SKTellink',
        821038 => 'SKTellink',
        821039 => 'LG U+',
        821042 => 'KT',
        821043 => 'KT',
        821044 => 'KT',
        821050 => 'SKTellink',
        821051 => 'KT',
        821052 => 'SKTellink',
        821053 => 'SKTellink',
        821054 => 'SKTellink',
        821055 => 'LG U+',
        821056 => 'LG U+',
        821057 => 'LG U+',
        821058 => 'LG U+',
        821062 => 'SKTellink',
        821063 => 'SKTellink',
        821064 => 'SKTellink',
        821065 => 'KT',
        821066 => 'KT',
        821067 => 'KT',
        821068 => 'KT',
        821071 => 'SKTellink',
        821072 => 'KT',
        821073 => 'KT',
        821074 => 'KT',
        821075 => 'LG U+',
        821076 => 'LG U+',
        821077 => 'LG U+',
        821079 => 'LG U+',
        821080 => 'LG U+',
        821081 => 'LG U+',
        821082 => 'LG U+',
        821083 => 'LG U+',
        821084 => 'LG U+',
        821085 => 'SKTellink',
        821086 => 'SKTellink',
        821087 => 'SKTellink',
        821088 => 'SKTellink',
        821089 => 'SKTellink',
        821090 => 'SKTellink',
        821091 => 'SKTellink',
        821092 => 'SKTellink',
        821093 => 'SKTellink',
        821094 => 'SKTellink',
        821095 => 'KT',
        821096 => 'KT',
        821097 => 'KT',
        821098 => 'KT',
        821099 => 'KT',
        8210590 => 'SKTellink',
        8210591 => 'SKTellink',
        8210592 => 'SKTellink',
        8210593 => 'SKTellink',
        8210594 => 'SKTellink',
        8210595 => 'SKTellink',
    ];
}
