<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_94
{
    public const DATA = [
        9470 => 'Mobitel',
        9471 => 'Mobitel',
        9472 => 'Etisalat',
        9474 => 'Dialog',
        9475 => 'Airtel',
        9476 => 'Dialog',
        9477 => 'Dialog',
        9478 => 'Hutch',
    ];
}
