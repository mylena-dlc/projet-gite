<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\ru;

/**
 * @internal
 */
class Ru_374
{
    public const DATA = [
        3745 => 'Юком',
        3747 => 'ВиваСелл-МТС',
        37433 => 'Team Telecom Armenia',
        37441 => 'Юком',
        37443 => 'Team Telecom Armenia',
        37444 => 'Юком',
        37449 => 'ВиваСелл-МТС',
        37488 => 'ВиваСелл-МТС',
        37491 => 'Team Telecom Armenia',
        37493 => 'ВиваСелл-МТС',
        37494 => 'ВиваСелл-МТС',
        37495 => 'Юком',
        37496 => 'Team Telecom Armenia',
        37497 => 'Team Telecom Armenia',
        37498 => 'ВиваСелл-МТС',
        37499 => 'Team Telecom Armenia',
    ];
}
