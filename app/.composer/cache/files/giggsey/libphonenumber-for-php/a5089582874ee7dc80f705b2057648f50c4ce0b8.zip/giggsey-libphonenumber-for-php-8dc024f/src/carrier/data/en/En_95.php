<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_95
{
    public const DATA = [
        9592 => 'MPT',
        9593 => 'MPT',
        9595 => 'MPT',
        9596 => 'Mytel',
        9597 => 'Telenor',
        95940 => 'MPT',
        95941 => 'MPT',
        95942 => 'MPT',
        95943 => 'MPT',
        95944 => 'MPT',
        95945 => 'MPT',
        95947 => 'MPT',
        95949 => 'MPT',
        95973 => 'MPT',
        95981 => 'MPT',
        95983 => 'MPT',
        95984 => 'MPT',
        95985 => 'MPT',
        95986 => 'MPT',
        95987 => 'MPT',
        95988 => 'MPT',
        95989 => 'MPT',
        95991 => 'MPT',
        95994 => 'Ooredoo',
        95995 => 'Ooredoo',
        95996 => 'Ooredoo',
        95997 => 'Ooredoo',
        95998 => 'Ooredoo',
    ];
}
