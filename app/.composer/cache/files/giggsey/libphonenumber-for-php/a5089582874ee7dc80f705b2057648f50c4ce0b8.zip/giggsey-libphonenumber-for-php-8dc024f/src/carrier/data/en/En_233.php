<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_233
{
    public const DATA = [
        23320 => 'Vodafone',
        23323 => 'airteltiGO',
        23324 => 'MTN',
        23325 => 'MTN',
        23326 => 'airteltiGO',
        23327 => 'airteltiGO',
        23328 => 'Expresso',
        23329 => 'National Security',
        23350 => 'Vodafone',
        23353 => 'MTN',
        23354 => 'MTN',
        23355 => 'MTN',
        23356 => 'airteltiGO',
        23357 => 'airteltiGO',
        23359 => 'MTN',
    ];
}
