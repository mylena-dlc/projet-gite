<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_593
{
    public const DATA = [
        59393 => 'Claro',
        59398 => 'Claro',
        593959 => 'Claro',
        593960 => 'CNT',
        593961 => 'CNT',
        593963 => 'Movistar',
        593964 => 'Movistar',
        593966 => 'CNT',
        593967 => 'Claro',
        593968 => 'Claro',
        593969 => 'Claro',
        593979 => 'Claro',
        593983 => 'Movistar',
        593984 => 'Movistar',
        593987 => 'Movistar',
        593990 => 'Claro',
        593991 => 'Claro',
        593993 => 'Claro',
        593994 => 'Claro',
        593995 => 'Movistar',
        593996 => 'CNT',
        593997 => 'Claro',
        593998 => 'Movistar',
        5939586 => 'Movistar',
        5939587 => 'Movistar',
        5939588 => 'Movistar',
        5939589 => 'Movistar',
        5939620 => 'CNT',
        5939621 => 'CNT',
        5939622 => 'CNT',
        5939623 => 'CNT',
        5939624 => 'CNT',
        5939625 => 'Movistar',
        5939626 => 'Movistar',
        5939627 => 'Movistar',
        5939628 => 'Movistar',
        5939629 => 'Movistar',
        5939690 => 'Movistar',
        5939786 => 'Movistar',
        5939787 => 'Movistar',
        5939788 => 'Movistar',
        5939789 => 'Movistar',
        5939790 => 'Movistar',
        5939791 => 'Movistar',
        5939792 => 'Movistar',
        5939793 => 'Movistar',
        5939820 => 'CNT',
        5939821 => 'CNT',
        5939822 => 'CNT',
        5939823 => 'CNT',
        5939824 => 'CNT',
        5939920 => 'Claro',
        5939921 => 'Claro',
        5939922 => 'Claro',
        5939923 => 'Claro',
        5939924 => 'Claro',
        5939925 => 'Movistar',
        5939926 => 'Movistar',
        5939927 => 'Movistar',
        5939928 => 'Movistar',
        5939929 => 'Movistar',
        5939990 => 'Movistar',
        5939991 => 'Claro',
        5939992 => 'Movistar',
        5939993 => 'Claro',
        5939994 => 'Claro',
        5939995 => 'Claro',
        5939996 => 'Claro',
        5939997 => 'Movistar',
        5939998 => 'Movistar',
        5939999 => 'Movistar',
    ];
}
