<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_691
{
    public const DATA = [
        6918 => 'FSMTC',
        69132 => 'FSMTC',
        69133 => 'FSMTC',
        69135 => 'FSMTC',
        69137 => 'FSMTC',
        69192 => 'FSMTC',
        69193 => 'FSMTC',
        69194 => 'FSMTC',
        69195 => 'FSMTC',
        69196 => 'BOOM!',
        69197 => 'FSMTC',
    ];
}
