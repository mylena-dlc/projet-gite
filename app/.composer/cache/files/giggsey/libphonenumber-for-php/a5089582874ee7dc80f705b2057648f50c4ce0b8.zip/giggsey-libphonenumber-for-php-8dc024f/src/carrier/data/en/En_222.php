<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_222
{
    public const DATA = [
        22220 => 'Chinguitel',
        22221 => 'Chinguitel',
        22222 => 'Chinguitel',
        22223 => 'Chinguitel',
        22224 => 'Chinguitel',
        22226 => 'Chinguitel',
        22227 => 'Chinguitel',
        22228 => 'Chinguitel',
        22229 => 'Chinguitel',
        22230 => 'Mattel',
        22231 => 'Mattel',
        22232 => 'Mattel',
        22233 => 'Mattel',
        22234 => 'Mattel',
        22236 => 'Mattel',
        22237 => 'Mattel',
        22238 => 'Mattel',
        22239 => 'Mattel',
        22240 => 'Mauritel',
        22241 => 'Mauritel',
        22242 => 'Mauritel',
        22243 => 'Mauritel',
        22244 => 'Mauritel',
        22246 => 'Mauritel',
        22247 => 'Mauritel',
        22248 => 'Mauritel',
        22249 => 'Mauritel',
    ];
}
