<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_84
{
    public const DATA = [
        843 => 'Viettel',
        847 => 'MobiFone',
        8430 => 'MobiFone',
        8451 => 'MobiFone',
        8452 => 'Vietnamobile',
        8455 => 'Reddi',
        8456 => 'Vietnamobile',
        8458 => 'Vietnamobile',
        8459 => 'G-Mobile',
        8481 => 'Vinaphone',
        8482 => 'Vinaphone',
        8483 => 'Vinaphone',
        8484 => 'Vinaphone',
        8485 => 'Vinaphone',
        8486 => 'Viettel',
        8487 => 'Vinaphone',
        8488 => 'Vinaphone',
        8489 => 'MobiFone',
        8490 => 'MobiFone',
        8491 => 'Vinaphone',
        8492 => 'Vietnamobile',
        8493 => 'MobiFone',
        8494 => 'Vinaphone',
        8496 => 'Viettel',
        8497 => 'Viettel',
        8498 => 'Viettel',
        84993 => 'G-Mobile',
        84994 => 'G-Mobile',
        84995 => 'G-Mobile',
        84996 => 'G-Mobile',
        84997 => 'G-Mobile',
        84998 => 'Indochina Telecom',
        84999 => 'Indochina Telecom',
    ];
}
