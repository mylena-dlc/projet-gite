<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_43
{
    public const DATA = [
        43650 => 'tele.ring',
        43660 => 'Hutchison Drei Austria',
        43664 => 'A1 TA',
        43670 => 'spusu',
        43676 => 'T-Mobile AT',
        43688 => 'Orange AT',
        43699 => 'Orange AT',
        436770 => 'T-Mobile AT',
        436771 => 'T-Mobile AT',
        436772 => 'T-Mobile AT',
        436778 => 'T-Mobile AT',
        436779 => 'T-Mobile AT',
        4368181 => 'A1 TA',
        4368182 => 'A1 TA',
        4368183 => 'Orange AT',
        4368184 => 'A1 TA',
    ];
}
