<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_685
{
    public const DATA = [
        68571 => 'Bluesky',
        68572 => 'Digicel',
        68573 => 'Digicel',
        68575 => 'Bluesky',
        68576 => 'Bluesky',
        68577 => 'Digicel',
        68583 => 'Digicel',
        68584 => 'Digicel',
        68585 => 'Digicel',
        68586 => 'Digicel',
        68587 => 'Digicel',
    ];
}
