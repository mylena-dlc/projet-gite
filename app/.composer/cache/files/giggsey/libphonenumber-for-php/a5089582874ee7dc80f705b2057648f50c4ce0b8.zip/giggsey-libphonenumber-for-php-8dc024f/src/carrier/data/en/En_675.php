<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_675
{
    public const DATA = [
        6757 => 'Digicel',
        67575 => 'bmobile',
        67576 => 'bmobile',
        67577 => 'bmobile',
        67578 => 'bmobile',
        67581 => 'Vodafone',
        67582 => 'Vodafone',
        67583 => 'Vodafone',
        67588 => 'Digicel',
    ];
}
