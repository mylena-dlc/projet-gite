<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_254
{
    public const DATA = [
        25410 => 'Airtel',
        25411 => 'Safaricom',
        25413 => 'NRG Media Limited',
        25470 => 'Safaricom',
        25471 => 'Safaricom',
        25472 => 'Safaricom',
        25473 => 'Airtel',
        25474 => 'Safaricom',
        25475 => 'Airtel',
        25477 => 'Telkom',
        25478 => 'Airtel',
        25479 => 'Safaricom',
        254120 => 'Telkom',
        254121 => 'Infura',
        254124 => 'Finserve',
        254744 => 'Homeland Media',
        254747 => 'JTL',
        254757 => 'Safaricom',
        254758 => 'Safaricom',
        254759 => 'Safaricom',
        254760 => 'Mobile Pay',
        254761 => 'Airtel',
        254762 => 'Airtel',
        254763 => 'Finserve',
        254764 => 'Finserve',
        254765 => 'Finserve',
        254766 => 'Finserve',
        254767 => 'Sema Mobile',
        254768 => 'Safaricom',
        254769 => 'Safaricom',
    ];
}
