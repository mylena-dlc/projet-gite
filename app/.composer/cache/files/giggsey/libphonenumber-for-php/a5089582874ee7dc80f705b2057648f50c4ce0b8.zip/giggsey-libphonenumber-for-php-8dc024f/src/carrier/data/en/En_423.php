<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_423
{
    public const DATA = [
        42364 => 'Soracom',
        42366 => 'Telecom Liechtenstein',
        42373 => 'Telecom Liechtenstein',
        42374 => 'First Mobile',
        42377 => 'Swisscom',
        42378 => 'Salt',
        42379 => 'Telecom Liechtenstein',
        423650 => 'Telecom Liechtenstein',
        423651 => 'Cubic',
        423652 => 'Cubic',
        423653 => 'Cubic',
        423654 => 'Cubic',
        423656 => 'Cubic',
        423659 => 'Telecom Liechtenstein',
        423661 => 'Dimoco',
        423666 => 'Datamobile AG',
    ];
}
