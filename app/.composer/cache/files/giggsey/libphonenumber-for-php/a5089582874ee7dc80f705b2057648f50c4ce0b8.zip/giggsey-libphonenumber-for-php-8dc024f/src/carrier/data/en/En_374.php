<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_374
{
    public const DATA = [
        3745 => 'Ucom',
        3747 => 'VivaCell-MTS',
        37433 => 'Team Telecom Armenia',
        37441 => 'Ucom',
        37443 => 'Team Telecom Armenia',
        37444 => 'Ucom',
        37449 => 'VivaCell-MTS',
        37488 => 'VivaCell-MTS',
        37491 => 'Team Telecom Armenia',
        37493 => 'VivaCell-MTS',
        37494 => 'VivaCell-MTS',
        37495 => 'Ucom',
        37496 => 'Team Telecom Armenia',
        37497 => 'Team Telecom Armenia',
        37498 => 'VivaCell-MTS',
        37499 => 'Team Telecom Armenia',
    ];
}
