<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_996
{
    public const DATA = [
        99620 => 'Aktel',
        99622 => 'Sky mobile',
        99650 => 'Nur Telecom',
        99651 => 'Katel',
        99654 => 'Aktel',
        99655 => 'ALFA Telecom',
        99656 => 'Winline',
        99657 => 'Sotel',
        99670 => 'Nur Telecom',
        99675 => 'ALFA Telecom',
        99677 => 'Sky mobile',
        99688 => 'ALFA Telecom',
        99691 => 'Smart Connect',
        996506 => 'Winline',
        996600 => 'Sky mobile',
        996990 => 'ALFA Telecom',
        996995 => 'ALFA Telecom',
        996996 => 'Sky mobile',
        996997 => 'ALFA Telecom',
        996998 => 'ALFA Telecom',
        996999 => 'ALFA Telecom',
        99631258 => 'Sky mobile',
        996312973 => 'Nur Telecom',
    ];
}
