<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_247
{
    public const DATA = [
        24741 => 'Sure South Atlantic',
        24742 => 'Sure South Atlantic',
        24743 => 'Sure South Atlantic',
        24745 => 'Sure South Atlantic',
        24746 => 'Sure South Atlantic',
        24747 => 'Sure South Atlantic',
        24748 => 'Sure South Atlantic',
    ];
}
