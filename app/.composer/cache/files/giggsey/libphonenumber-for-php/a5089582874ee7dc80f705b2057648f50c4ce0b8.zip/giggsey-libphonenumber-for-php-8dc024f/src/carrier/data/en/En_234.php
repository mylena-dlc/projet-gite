<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_234
{
    public const DATA = [
        234701 => 'Airtel',
        234703 => 'MTN',
        234704 => 'MTN',
        234705 => 'Glo',
        234706 => 'MTN',
        234707 => 'MTN',
        234708 => 'Airtel',
        234709 => 'Multilinks',
        234801 => 'MAFAB',
        234802 => 'Airtel',
        234803 => 'MTN',
        234804 => 'Ntel',
        234805 => 'Glo',
        234806 => 'MTN',
        234807 => 'Glo',
        234808 => 'Airtel',
        234809 => '9mobile',
        234810 => 'MTN',
        234811 => 'Glo',
        234812 => 'Airtel',
        234813 => 'MTN',
        234814 => 'MTN',
        234815 => 'Glo',
        234816 => 'MTN',
        234817 => '9mobile',
        234818 => '9mobile',
        234819 => 'Starcomms',
        234901 => 'Airtel',
        234902 => 'Airtel',
        234903 => 'MTN',
        234904 => 'Airtel',
        234905 => 'Glo',
        234906 => 'MTN',
        234907 => 'Airtel',
        234908 => '9mobile',
        234909 => '9mobile',
        234911 => 'Airtel',
        234912 => 'Airtel',
        234913 => 'MTN',
        234915 => 'Glo',
        234916 => 'MTN',
        2347020 => 'Smile',
        2347021 => 'Ntel',
        2347022 => 'Ntel',
        2347024 => 'Prestel',
        2347025 => 'MTN',
        2347026 => 'MTN',
        2347027 => 'Multilinks',
        2347028 => 'Starcomms',
        2347029 => 'Starcomms',
    ];
}
