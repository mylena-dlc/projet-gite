<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_249
{
    public const DATA = [
        24910 => 'Sudatel',
        24911 => 'Sudatel',
        24912 => 'Sudatel',
        24990 => 'Zain',
        24991 => 'Zain',
        24992 => 'MTN',
        24993 => 'MTN',
        24995 => 'Network of The World Ltd',
        24996 => 'Zain',
        24999 => 'MTN',
    ];
}
