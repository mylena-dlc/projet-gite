<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_359
{
    public const DATA = [
        35987 => 'Vivacom',
        35988 => 'A1',
        35989 => 'Telenor',
        359988 => 'Bob',
        359989 => 'A1',
        3599960 => 'A1',
        3599961 => 'A1',
        3599962 => 'A1',
        3599964 => 'Telenor',
        3599965 => 'Telenor',
        3599966 => 'Telenor',
        3599967 => 'Vivacom',
        3599968 => 'Vivacom',
        3599969 => 'Vivacom',
        3599990 => 'A1',
        3599991 => 'A1',
        3599992 => 'A1',
        3599993 => 'A1',
        3599994 => 'Telenor',
        3599995 => 'Telenor',
        3599996 => 'Vivacom',
        3599997 => 'Vivacom',
        3599998 => 'Vivacom',
        3599999 => 'Vivacom',
    ];
}
