<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\uk;

/**
 * @internal
 */
class Uk_380
{
    public const DATA = [
        38039 => 'Київстар',
        38050 => 'Vodafone Україна',
        38066 => 'Vodafone Україна',
        38067 => 'Київстар',
        38068 => 'Київстар',
        38075 => 'Vodafone Україна',
        38077 => 'Київстар',
        38091 => 'ТриМоб',
        38094 => 'Інтертелеком',
        38095 => 'Vodafone Україна',
        38096 => 'Київстар',
        38097 => 'Київстар',
        38098 => 'Київстар',
        38099 => 'Vodafone Україна',
    ];
}
