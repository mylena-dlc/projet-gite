<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_229
{
    public const DATA = [
        2294 => 'Celtiis',
        2295 => 'MTN',
        22942 => 'MTN',
        22946 => 'MTN',
        22955 => 'Moov',
        22960 => 'Moov',
        22961 => 'MTN',
        22962 => 'MTN',
        22963 => 'Moov',
        22964 => 'Moov',
        22965 => 'Moov',
        22966 => 'MTN',
        22967 => 'MTN',
        22968 => 'Moov',
        22969 => 'MTN',
        22990 => 'MTN',
        22991 => 'MTN',
        22993 => 'BLK',
        22994 => 'Moov',
        22995 => 'Moov',
        22996 => 'MTN',
        22997 => 'MTN',
        22998 => 'Moov',
        22999 => 'Moov',
        229014 => 'SBIN',
        229015 => 'MTN',
        2290142 => 'MTN',
        2290145 => 'Moov',
        2290146 => 'MTN',
        2290155 => 'Moov',
        2290158 => 'Moov',
        2290160 => 'Moov',
        2290161 => 'MTN',
        2290162 => 'MTN',
        2290163 => 'Moov',
        2290164 => 'Moov',
        2290165 => 'Moov',
        2290166 => 'MTN',
        2290167 => 'MTN',
        2290168 => 'Moov',
        2290169 => 'MTN',
        2290190 => 'MTN',
        2290191 => 'MTN',
        2290194 => 'Moov',
        2290195 => 'Moov',
        2290196 => 'MTN',
        2290197 => 'MTN',
        2290198 => 'Moov',
        2290199 => 'Moov',
    ];
}
