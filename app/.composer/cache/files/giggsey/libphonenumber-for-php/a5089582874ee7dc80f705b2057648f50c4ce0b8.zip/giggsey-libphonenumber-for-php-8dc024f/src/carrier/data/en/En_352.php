<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_352
{
    public const DATA = [
        35262 => 'POST',
        35266 => 'Orange',
        35269 => 'Tango',
        352651 => 'POST',
        352658 => 'POST',
        352671 => 'JOIN',
        352678 => 'JOIN',
    ];
}
