<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_372
{
    public const DATA = [
        37250 => 'Telia Eesti AS',
        37252 => 'Telia Eesti AS',
        37254 => 'Telia Eesti AS',
        37255 => 'Tele 2',
        37256 => 'Elisa',
        37257 => 'Telia Eesti AS',
        37258 => 'Tele 2',
        37259 => 'Telia Eesti AS',
        37281 => 'Telia Eesti AS',
        37282 => 'Elisa',
        37283 => 'Tele 2',
        37284 => 'Tele 2',
        372519 => 'Telia Eesti AS',
        372530 => 'Telia Eesti AS',
        372533 => 'Telia Eesti AS',
        372534 => 'Telia Eesti AS',
        372536 => 'Telia Eesti AS',
        372537 => 'Telia Eesti AS',
        372538 => 'Telia Eesti AS',
        372539 => 'Telia Eesti AS',
        372545 => 'Elisa',
        372589 => 'Elisa',
        372829 => 'Tele 2',
        3725461 => 'Elisa',
        3725462 => 'Elisa',
        3725463 => 'Elisa',
        3728110 => 'Tele 2',
        3728111 => 'Elisa',
        3728123 => 'Elisa',
        3728200 => 'Telia Eesti AS',
        3728203 => 'Telia Eesti AS',
        3728204 => 'Tele 2',
        3728206 => 'Tele 2',
        3728216 => 'Tele 2',
        3728217 => 'Tele 2',
        3728218 => 'Tele 2',
        3728270 => 'Telia Eesti AS',
        3728271 => 'Telia Eesti AS',
        3728272 => 'Telia Eesti AS',
        3728273 => 'Telia Eesti AS',
        3728282 => 'Telia Eesti AS',
        3728285 => 'Tele 2',
        3728286 => 'Tele 2',
        3728287 => 'Tele 2',
        37254664 => 'Elisa',
        37254665 => 'Elisa',
        37254667 => 'Elisa',
        37254668 => 'Elisa',
        37254669 => 'Elisa',
        37259120 => 'Tele 2',
        37259121 => 'Tele 2',
        37259140 => 'Tele 2',
        37259144 => 'Tele 2',
        37282056 => 'Tele 2',
        37282057 => 'Tele 2',
        37282058 => 'Tele 2',
        37282059 => 'Tele 2',
        37282199 => 'Tele 2',
        37284510 => 'Telia Eesti AS',
        37284511 => 'Telia Eesti AS',
        37284512 => 'Telia Eesti AS',
        372591410 => 'Tele 2',
        372591411 => 'Tele 2',
        372591412 => 'Tele 2',
        372591413 => 'Tele 2',
    ];
}
