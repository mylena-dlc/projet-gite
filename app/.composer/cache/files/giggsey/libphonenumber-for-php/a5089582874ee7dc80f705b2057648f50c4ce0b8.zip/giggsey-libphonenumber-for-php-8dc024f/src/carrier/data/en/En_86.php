<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_86
{
    public const DATA = [
        8615 => 'China Mobile',
        86130 => 'China Unicom',
        86131 => 'China Unicom',
        86132 => 'China Unicom',
        86133 => 'China Telecom',
        86135 => 'China Mobile',
        86136 => 'China Mobile',
        86137 => 'China Mobile',
        86138 => 'China Mobile',
        86139 => 'China Mobile',
        86145 => 'China Unicom',
        86147 => 'China Mobile',
        86153 => 'China Telecom',
        86155 => 'China Unicom',
        86156 => 'China Unicom',
        86166 => 'China Unicom',
        86167 => 'China Unicom',
        86171 => 'China Unicom',
        86172 => 'China Mobile',
        86173 => 'China Telecom',
        86174 => 'China Telecom',
        86175 => 'China Unicom',
        86176 => 'China Unicom',
        86177 => 'China Telecom',
        86178 => 'China Mobile',
        86180 => 'China Telecom',
        86181 => 'China Telecom',
        86182 => 'China Mobile',
        86183 => 'China Mobile',
        86184 => 'China Mobile',
        86185 => 'China Unicom',
        86186 => 'China Unicom',
        86187 => 'China Mobile',
        86188 => 'China Mobile',
        86189 => 'China Telecom',
        86190 => 'China Telecom',
        86191 => 'China Telecom',
        86192 => 'CBN',
        86193 => 'China Telecom',
        86195 => 'China Mobile',
        86196 => 'China Unicom',
        86197 => 'China Mobile',
        86198 => 'China Mobile',
        86199 => 'China Telecom',
        861340 => 'China Mobile',
        861341 => 'China Mobile',
        861342 => 'China Mobile',
        861343 => 'China Mobile',
        861344 => 'China Mobile',
        861345 => 'China Mobile',
        861346 => 'China Mobile',
        861347 => 'China Mobile',
        861348 => 'China Mobile',
        861700 => 'China Telecom',
        861701 => 'China Telecom',
        861702 => 'China Telecom',
        861703 => 'China Mobile',
        861704 => 'China Unicom',
        861705 => 'China Mobile',
        861706 => 'China Mobile',
        861707 => 'China Unicom',
        861708 => 'China Unicom',
        861709 => 'China Unicom',
    ];
}
