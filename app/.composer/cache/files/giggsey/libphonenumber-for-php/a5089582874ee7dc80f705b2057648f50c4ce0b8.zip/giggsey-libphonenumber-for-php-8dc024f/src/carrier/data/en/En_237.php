<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_237
{
    public const DATA = [
        23762 => 'Camtel',
        23764 => 'Orange',
        23766 => 'NEXTTEL',
        23767 => 'MTN Cameroon',
        23769 => 'Orange',
        237650 => 'MTN Cameroon',
        237651 => 'MTN Cameroon',
        237652 => 'MTN Cameroon',
        237653 => 'MTN Cameroon',
        237654 => 'MTN Cameroon',
        237655 => 'Orange',
        237656 => 'Orange',
        237657 => 'Orange',
        237658 => 'Orange',
        237659 => 'Orange',
        237680 => 'MTN Cameroon',
        237681 => 'MTN Cameroon',
        237682 => 'MTN Cameroon',
        237683 => 'MTN Cameroon',
        237684 => 'NEXTTEL',
        237685 => 'NEXTTEL',
        237686 => 'Orange',
        237687 => 'Orange',
        237688 => 'Orange',
        237689 => 'Orange',
    ];
}
