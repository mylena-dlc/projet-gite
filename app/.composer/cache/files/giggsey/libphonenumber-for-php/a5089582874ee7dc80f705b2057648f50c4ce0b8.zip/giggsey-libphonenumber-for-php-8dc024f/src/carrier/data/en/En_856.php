<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_856
{
    public const DATA = [
        856202 => 'ETL',
        856203 => 'ETL',
        856205 => 'Lao Telecom',
        856207 => 'Beeline',
        856208 => 'Best Telecom',
        856209 => 'Unitel',
        856302 => 'ETL',
        856304 => 'Unitel',
    ];
}
