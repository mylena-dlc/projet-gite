<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_974
{
    public const DATA = [
        97430 => 'Vodafone',
        97433 => 'ooredoo',
        97450 => 'ooredoo',
        97451 => 'ooredoo',
        97452 => 'ooredoo',
        97455 => 'ooredoo',
        97466 => 'ooredoo',
        97470 => 'Vodafone',
        97471 => 'Vodafone',
        97474 => 'Vodafone',
        97477 => 'Vodafone',
        974310 => 'Vodafone',
        974311 => 'Vodafone',
        974312 => 'Vodafone',
        974313 => 'Vodafone',
        974314 => 'Vodafone',
        974315 => 'Vodafone',
        974316 => 'Vodafone',
        974399 => 'ooredoo',
        974599 => 'ooredoo',
        974600 => 'ooredoo',
        974720 => 'Vodafone',
        974721 => 'Vodafone',
        974722 => 'Vodafone',
        974723 => 'Vodafone',
        974724 => 'Vodafone',
        974725 => 'Vodafone',
        974726 => 'Vodafone',
    ];
}
