<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_211
{
    public const DATA = [
        21112 => 'Sudatel Group',
        21191 => 'Zain',
        21192 => 'MTN',
        21195 => 'Network of the World',
        21197 => 'Gemtel',
        21198 => 'Digitel',
        21199 => 'MTN',
    ];
}
