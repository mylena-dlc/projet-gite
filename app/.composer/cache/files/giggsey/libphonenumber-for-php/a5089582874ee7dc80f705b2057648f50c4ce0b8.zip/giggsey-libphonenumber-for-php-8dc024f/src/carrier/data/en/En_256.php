<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_256
{
    public const DATA = [
        25670 => 'Airtel',
        25671 => 'UTL',
        25673 => 'Hamilton Telecom',
        25674 => 'Airtel',
        25675 => 'Airtel',
        25676 => 'MTN',
        25677 => 'MTN',
        25678 => 'MTN',
        256720 => 'Smile',
        256724 => 'Hamilton Telecom',
        256726 => 'Tangerine',
        256727 => 'Tangerine',
        256728 => 'Talkio',
        256790 => 'MTN',
        256798 => 'Africell',
        256799 => 'Africell',
    ];
}
