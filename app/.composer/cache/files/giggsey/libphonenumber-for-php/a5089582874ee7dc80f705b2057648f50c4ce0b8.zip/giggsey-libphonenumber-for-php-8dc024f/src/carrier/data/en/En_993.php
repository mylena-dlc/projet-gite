<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_993
{
    public const DATA = [
        9937 => 'TM-Cell',
        99361 => 'TM-Cell',
        99362 => 'TM-Cell',
        99363 => 'TM-Cell',
        99364 => 'TM-Cell',
        99365 => 'TM-Cell',
        99366 => 'MTS (BARASH Communication)',
        99367 => 'MTS (BARASH Communication)',
        99368 => 'MTS (BARASH Communication)',
        99369 => 'MTS (BARASH Communication)',
    ];
}
