<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_354
{
    public const DATA = [
        35461 => 'Vodafone',
        35462 => 'Vodafone',
        35466 => 'Vodafone',
        35467 => 'Vodafone',
        35469 => 'Vodafone',
        35476 => 'Nova',
        35477 => 'Nova',
        35478 => 'Nova',
        35479 => 'Nova',
        35482 => 'Vodafone',
        35483 => 'Síminn',
        35484 => 'Síminn',
        35485 => 'Síminn',
        35486 => 'Síminn',
        35489 => 'Síminn',
        354385 => 'Síminn',
        354388 => 'IMC',
        354389 => 'IMC',
        354630 => 'IMC',
        354632 => 'Tismi',
        354636 => 'Öryggisfjarskipti',
        354637 => 'Öryggisfjarskipti',
        354638 => 'Öryggisfjarskipti',
        354639 => 'Öryggisfjarskipti',
        354640 => 'Öryggisfjarskipti',
        354641 => 'Öryggisfjarskipti',
        354644 => 'Nova',
        354646 => 'IMC',
        354647 => 'IMC',
        354649 => 'Vodafone',
        354650 => 'IMC',
        354651 => 'IMC',
        354655 => 'Vodafone',
        354659 => 'Vodafone',
        354680 => 'Vodafone',
        354686 => 'Vodafone',
        354687 => 'Vodafone',
        354688 => 'Vodafone',
        354750 => 'Síminn',
        354755 => 'Síminn',
        354757 => 'Vodafone',
        354882 => 'Síminn',
        354883 => 'Síminn',
        354888 => 'Síminn',
    ];
}
