<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\fa;

/**
 * @internal
 */
class Fa_93
{
    public const DATA = [
        9370 => 'افغان بی سیم',
        9371 => 'افغان بی سیم',
        9372 => 'روشن',
        9373 => 'اتصالات',
        9375 => 'افغان تلکام',
        9376 => 'ام تی ان',
        9377 => 'ام تی ان',
        9378 => 'اتصالات',
        9379 => 'روشن',
        93744 => 'افغان تلکام',
        93747 => 'افغان تلکام',
        93748 => 'افغان تلکام',
        93749 => 'افغان تلکام',
    ];
}
