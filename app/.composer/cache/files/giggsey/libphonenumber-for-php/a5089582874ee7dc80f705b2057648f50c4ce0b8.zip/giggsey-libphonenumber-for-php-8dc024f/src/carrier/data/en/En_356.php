<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_356
{
    public const DATA = [
        35672 => 'GO Mobile',
        35677 => 'Melita Mobile',
        35679 => 'GO Mobile',
        35692 => 'epic',
        35699 => 'epic',
        356981 => 'Melita Mobile',
        356988 => 'GO Mobile',
        356989 => 'epic',
        3569696 => 'epic',
    ];
}
