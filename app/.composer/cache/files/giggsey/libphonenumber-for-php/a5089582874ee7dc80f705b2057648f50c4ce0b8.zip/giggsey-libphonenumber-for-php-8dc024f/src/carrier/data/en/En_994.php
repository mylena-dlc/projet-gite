<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_994
{
    public const DATA = [
        9946 => 'Naxtel',
        9947 => 'Nar Mobile',
        99410 => 'Azercell',
        99440 => 'FONEX',
        99444 => 'Aztelekom',
        99450 => 'Azercell',
        99451 => 'Azercell',
        99455 => 'Bakcell',
        99499 => 'Bakcell',
        99436554 => 'Naxtel',
    ];
}
