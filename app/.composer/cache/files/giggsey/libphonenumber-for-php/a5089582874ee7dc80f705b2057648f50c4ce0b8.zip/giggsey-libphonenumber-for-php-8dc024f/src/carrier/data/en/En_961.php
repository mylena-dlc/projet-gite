<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_961
{
    public const DATA = [
        96130 => 'Touch',
        96131 => 'Alfa',
        96132 => 'Alfa',
        96133 => 'Alfa',
        96134 => 'Alfa',
        96135 => 'Alfa',
        96136 => 'Touch',
        96137 => 'Touch',
        96138 => 'Touch',
        96139 => 'Touch',
        961700 => 'Touch',
        961701 => 'Alfa',
        961702 => 'Alfa',
        961703 => 'Alfa',
        961704 => 'Alfa',
        961705 => 'Alfa',
        961706 => 'Touch',
        961707 => 'Touch',
        961708 => 'Touch',
        961709 => 'Touch',
        961710 => 'Alfa',
        961711 => 'Touch',
        961712 => 'Touch',
        961713 => 'Touch',
        961714 => 'Touch',
        961715 => 'Touch',
        961716 => 'Alfa',
        961717 => 'Alfa',
        961718 => 'Alfa',
        961719 => 'Alfa',
        961760 => 'Touch',
        961761 => 'Alfa',
        961763 => 'Alfa',
        961764 => 'Alfa',
        961765 => 'Alfa',
        961766 => 'Touch',
        961767 => 'Touch',
        961768 => 'Touch',
        961769 => 'Touch',
        961788 => 'Touch',
        961789 => 'Touch',
        961791 => 'Alfa',
        961793 => 'Alfa',
        961810 => 'Touch',
        961811 => 'Alfa',
        961812 => 'Alfa',
        961813 => 'Alfa',
        961814 => 'Alfa',
        961815 => 'Alfa',
        961816 => 'Touch',
        961817 => 'Touch',
        961818 => 'Touch',
        961819 => 'Touch',
    ];
}
