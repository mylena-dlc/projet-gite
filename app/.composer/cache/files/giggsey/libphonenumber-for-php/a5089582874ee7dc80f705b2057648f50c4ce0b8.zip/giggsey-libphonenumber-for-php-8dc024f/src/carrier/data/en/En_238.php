<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_238
{
    public const DATA = [
        23836 => 'CVMOVEL',
        23851 => 'T+',
        23852 => 'T+',
        23853 => 'T+',
        23858 => 'CVMOVEL',
        23859 => 'CVMOVEL',
        23891 => 'T+',
        23892 => 'T+',
        23893 => 'T+',
        23895 => 'CVMOVEL',
        23897 => 'CVMOVEL',
        23898 => 'CVMOVEL',
        23899 => 'CVMOVEL',
    ];
}
