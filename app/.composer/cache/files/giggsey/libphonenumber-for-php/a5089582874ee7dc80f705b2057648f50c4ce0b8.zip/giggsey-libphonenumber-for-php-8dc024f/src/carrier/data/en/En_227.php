<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_227
{
    public const DATA = [
        22723 => 'Orange',
        22770 => 'Orange',
        22774 => 'Moov',
        22777 => 'Airtel',
        22780 => 'Orange',
        22781 => 'Orange',
        22782 => 'Orange',
        22783 => 'Niger Telecoms',
        22784 => 'Moov',
        22785 => 'Moov',
        22786 => 'Airtel',
        22787 => 'Airtel',
        22788 => 'Airtel',
        22789 => 'Airtel',
        22790 => 'Orange',
        22791 => 'Orange',
        22792 => 'Orange',
        22793 => 'Niger Telecoms',
        22794 => 'Moov',
        22795 => 'Moov',
        22796 => 'Airtel',
        22797 => 'Airtel',
        22798 => 'Airtel',
        22799 => 'Airtel',
    ];
}
