<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_350
{
    public const DATA = [
        35051 => 'Gibfibre',
        35052 => 'Gibfibre',
        35054 => 'GibTel',
        35056 => 'GibTel',
        35057 => 'GibTel',
        35058 => 'GibTel',
        350601 => 'Melmasti',
        350606 => 'GibTel',
    ];
}
