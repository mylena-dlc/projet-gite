<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_228
{
    public const DATA = [
        22870 => 'Togo Telecom',
        22871 => 'Togo Telecom',
        22872 => 'Togo Telecom',
        22879 => 'Moov',
        22890 => 'Togo Telecom',
        22891 => 'Togo Telecom',
        22892 => 'Togo Telecom',
        22893 => 'Togo Telecom',
        22896 => 'Moov',
        22897 => 'TOGOCEL',
        22898 => 'Moov',
        22899 => 'Moov',
    ];
}
