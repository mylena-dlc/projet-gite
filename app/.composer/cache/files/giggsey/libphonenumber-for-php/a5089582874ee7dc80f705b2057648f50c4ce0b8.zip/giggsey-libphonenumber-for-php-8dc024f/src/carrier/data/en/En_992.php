<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_992
{
    public const DATA = [
        9920 => 'ZET-MOBILE',
        99200 => 'Megafon',
        99201 => 'Megafon',
        99202 => 'Megafon',
        99207 => 'Megafon',
        99210 => 'O-Mobile',
        99211 => 'Tcell',
        99212 => 'Megafon',
        99217 => 'Babilon-M',
        99218 => 'ZET-MOBILE',
        99219 => 'ZET-MOBILE',
        99220 => 'O-Mobile',
        99221 => 'Megafon',
        99222 => 'O-Mobile',
        99227 => 'Megafon',
        99230 => 'O-Mobile',
        99240 => 'ZET-MOBILE',
        99241 => 'Megafon',
        99250 => 'Tcell',
        99255 => 'Megafon',
        99270 => 'Tcell',
        99271 => 'Babilon-M',
        99275 => 'Babilon-M',
        99277 => 'Tcell',
        99278 => 'Megafon',
        99280 => 'ZET-MOBILE',
        99281 => 'ZET-MOBILE',
        99287 => 'Megafon',
        99288 => 'Megafon',
        99290 => 'Megafon',
        99291 => 'ZET-MOBILE',
        99292 => 'Tcell',
        99293 => 'Tcell',
        99294 => 'Babilon-M',
        99297 => 'Megafon',
        99298 => 'Babilon-M',
        99299 => 'Tcell',
        992330 => 'ZET-MOBILE',
        992333 => 'ZET-MOBILE',
        992334 => 'ZET-MOBILE',
        992335 => 'ZET-MOBILE',
        992336 => 'ZET-MOBILE',
        992337 => 'ZET-MOBILE',
        992338 => 'ZET-MOBILE',
        992339 => 'ZET-MOBILE',
        992440 => 'ZET-MOBILE',
        992442 => 'ZET-MOBILE',
        992443 => 'ZET-MOBILE',
        992444 => 'ZET-MOBILE',
        992447 => 'ZET-MOBILE',
        992449 => 'ZET-MOBILE',
    ];
}
