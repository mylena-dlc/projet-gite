<?php

/**
 * libphonenumber-for-php data file
 * This file has been @generated from libphonenumber data
 * Do not modify!
 * @internal
 */

declare(strict_types=1);

namespace libphonenumber\carrier\data\en;

/**
 * @internal
 */
class En_679
{
    public const DATA = [
        6792 => 'Vodafone',
        6794 => 'Vodafone',
        6797 => 'Digicel',
        6799 => 'Vodafone',
        67950 => 'Digicel',
        67951 => 'Digicel',
        67955 => 'Digicel',
        67956 => 'Digicel',
        67958 => 'Vodafone',
        67980 => 'Vodafone',
        67983 => 'Vodafone',
        67984 => 'Vodafone',
        67986 => 'Vodafone',
        67987 => 'Vodafone',
        67989 => 'Vodafone',
    ];
}
